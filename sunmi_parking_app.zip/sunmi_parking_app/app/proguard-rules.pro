# Add project specific ProGuard rules here.
# Release build isn't minified by default (see app/build.gradle.kts), so
# this file is currently just a placeholder Gradle expects to exist.
