package com.nbg.parkingapp.api

import com.nbg.parkingapp.data.Prefs
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds a fresh [OdooApi] pointed at whatever server URL is currently
 * saved in [Prefs]. Rebuilt on demand (not cached as a singleton) since the
 * server URL can change from the Setup screen at any time.
 */
object ApiClient {

    fun build(prefs: Prefs): OdooApi? {
        val base = prefs.serverUrl
        if (base.isBlank()) return null
        val baseUrl = if (base.endsWith("/")) base else "$base/"

        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OdooApi::class.java)
    }
}
