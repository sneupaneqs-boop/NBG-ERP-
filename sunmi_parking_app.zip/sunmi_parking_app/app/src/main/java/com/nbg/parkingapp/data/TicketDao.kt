package com.nbg.parkingapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TicketDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ticket: TicketEntity)

    @Update
    suspend fun update(ticket: TicketEntity)

    @Query("SELECT * FROM tickets WHERE couponNumber = :coupon LIMIT 1")
    suspend fun findByCoupon(coupon: String): TicketEntity?

    @Query("SELECT * FROM tickets WHERE syncedEntry = 0 OR syncedExitPay = 0 ORDER BY entryEpochMillis ASC")
    suspend fun findUnsynced(): List<TicketEntity>

    @Query("SELECT COUNT(*) FROM tickets WHERE syncedEntry = 0 OR (syncedExitPay = 0 AND isPaid = 1)")
    fun pendingCount(): Flow<Int>

    @Query("SELECT * FROM tickets ORDER BY entryEpochMillis DESC LIMIT 100")
    fun recentTickets(): Flow<List<TicketEntity>>
}
