package com.nbg.parkingapp.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nbg.parkingapp.R
import com.nbg.parkingapp.api.ApiClient
import com.nbg.parkingapp.api.ConfigRequest
import com.nbg.parkingapp.api.PingRequest
import com.nbg.parkingapp.data.Prefs
import kotlinx.coroutines.launch

/** First-run (and re-visitable) setup: server URL, device API key, gate name. */
class SetupActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        prefs = Prefs(this)

        val serverUrlInput = findViewById<EditText>(R.id.serverUrlInput)
        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val gateNameInput = findViewById<EditText>(R.id.gateNameInput)
        val statusText = findViewById<TextView>(R.id.statusText)
        val testButton = findViewById<Button>(R.id.testConnectionButton)
        val doneButton = findViewById<Button>(R.id.doneButton)

        serverUrlInput.setText(prefs.serverUrl)
        apiKeyInput.setText(prefs.apiKey)
        gateNameInput.setText(prefs.gateName)

        testButton.setOnClickListener {
            val url = serverUrlInput.text.toString().trim()
            val key = apiKeyInput.text.toString().trim()
            val gate = gateNameInput.text.toString().trim().ifBlank { "Gate 1" }

            if (url.isBlank() || key.isBlank()) {
                statusText.text = "Please fill in the server URL and API key."
                return@setOnClickListener
            }

            // Save first so ApiClient.build() (which reads from Prefs) picks it up.
            prefs.serverUrl = url
            prefs.apiKey = key
            prefs.gateName = gate

            statusText.text = "Connecting…"
            doneButton.isEnabled = false

            lifecycleScope.launch {
                try {
                    val api = ApiClient.build(prefs)
                        ?: throw IllegalStateException("Invalid server URL")

                    val ping = api.ping(PingRequest(api_key = key))
                    if (!ping.isSuccessful || ping.body()?.success != true) {
                        statusText.text = "Could not connect. Check the URL and API key, " +
                            "and that this device can reach the server (HTTP ${ping.code()})."
                        return@launch
                    }

                    val configResp = api.getConfig(ConfigRequest(api_key = key))
                    val config = configResp.body()?.data
                    if (!configResp.isSuccessful || config == null) {
                        statusText.text = "Connected, but could not load rates from Odoo. Try again."
                        return@launch
                    }

                    prefs.cachedConfig = config
                    prefs.lastConfigSyncMillis = System.currentTimeMillis()

                    statusText.text = "✔ Connected as \"${config.company_name}\". " +
                        "Loaded ${config.vehicle_types.size} vehicle types and " +
                        "${config.categories.size} categories."
                    doneButton.isEnabled = true
                } catch (e: Exception) {
                    statusText.text = "Connection failed: ${e.message}"
                }
            }
        }

        doneButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        // Already configured before (re-entering Setup from the gear icon): allow
        // leaving without re-testing.
        if (prefs.isConfigured && prefs.cachedConfig != null) {
            statusText.text = "Currently connected to ${prefs.serverUrl}"
            doneButton.isEnabled = true
        }
    }
}
