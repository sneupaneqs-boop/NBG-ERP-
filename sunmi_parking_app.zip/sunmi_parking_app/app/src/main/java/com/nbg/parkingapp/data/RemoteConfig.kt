package com.nbg.parkingapp.data

/** Local mirror of the JSON returned by POST /parking/api/v1/config. */
data class RemoteConfig(
    val company_name: String = "",
    val company_address: String = "",
    val company_phone: String = "",
    val currency: String = "",
    val currency_symbol: String = "",
    val tax_rate: Double = 0.0,
    val receipt_width: String = "58",
    val fonepay_merchant_code: String = "",
    val vehicle_types: List<VehicleType> = emptyList(),
    val categories: List<Category> = emptyList(),
) {
    data class VehicleType(
        val code: String = "",
        val name: String = "",
        val hourly_charge: Double = 0.0,
        val lost_ticket_charge: Double = 0.0,
        val grace_period: Int = 0,
    )

    data class Category(
        val name: String = "",
        val free_minutes: Int = 0,
    )

    fun vehicleType(code: String): VehicleType? = vehicle_types.find { it.code == code }
    fun category(name: String): Category? = categories.find { it.name == name }
}
