package com.nbg.parkingapp.print

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.suspendCancellableCoroutine
import woyou.aidlservice.jiuiv5.IWoyouService
import kotlin.coroutines.resume

/**
 * Thin wrapper around Sunmi's built-in printer service (bound via AIDL,
 * package `woyou.aidlservice.jiuiv5` -- see
 * app/src/main/aidl/woyou/aidlservice/jiuiv5/IWoyouService.aidl).
 *
 * ON-DEVICE VERIFICATION NEEDED: the `symbology` constant passed to
 * printBarCode (CODE128 = 8 below) follows the common ESC/POS numbering
 * Sunmi's SDK documents use, but has not been confirmed against this exact
 * firmware (Sunmi OS 3.6.23 / SDK 1.2.0). If printed barcodes come out
 * wrong, check Sunmi's "Printer Demo" sample app (downloadable from Sunmi's
 * developer site for this model) for the exact constant and swap it in.
 */
class SunmiPrinterHelper(private val context: Context) {

    private var service: IWoyouService? = null
    private var bound = false

    companion object {
        private const val TAG = "SunmiPrinterHelper"
        private const val PRINTER_PACKAGE = "woyou.aidlservice.jiuiv5"
        private const val PRINTER_ACTION = "woyou.aidlservice.jiuiv5.IWoyouService"

        // ESC/POS-style barcode symbology constant used by Sunmi's SDK samples.
        private const val SYMBOLOGY_CODE128 = 8
        private const val ALIGN_CENTER = 1
        private const val ALIGN_LEFT = 0
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IWoyouService.Stub.asInterface(binder)
            bound = true
            Log.i(TAG, "Sunmi printer service connected")
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            bound = false
            Log.w(TAG, "Sunmi printer service disconnected")
        }
    }

    /** Call once, early (e.g. in Application.onCreate or MainActivity.onCreate). */
    fun connect() {
        if (bound) return
        val intent = Intent(PRINTER_ACTION).apply { setPackage(PRINTER_PACKAGE) }
        val ok = context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        if (!ok) {
            Log.e(TAG, "Could not bind Sunmi printer service -- is this really a Sunmi device?")
        }
    }

    fun disconnect() {
        if (bound) {
            runCatching { context.unbindService(connection) }
            bound = false
        }
    }

    val isReady: Boolean get() = service != null

    /** Returns true on success. Never throws -- printer errors are common (paper out, etc). */
    fun printCoupon(
        companyName: String,
        vehicleType: String,
        couponNumber: String,
        entryDisplay: String,
        gateName: String,
        barcodePayload: String,
    ): Boolean = safePrint {
        val s = service ?: return@safePrint false
        s.setAlignment(ALIGN_CENTER, null)
        s.printTextWithFont("$companyName\n", null, 32f, null)
        s.printTextWithFont("PARKING COUPON\n", null, 24f, null)
        s.lineWrap(1, null)
        s.setAlignment(ALIGN_LEFT, null)
        s.printText("Coupon : $couponNumber\n", null)
        s.printText("Vehicle: $vehicleType\n", null)
        s.printText("Entry  : $entryDisplay\n", null)
        s.printText("Gate   : $gateName\n", null)
        s.lineWrap(1, null)
        s.setAlignment(ALIGN_CENTER, null)
        s.printBarCode(barcodePayload, SYMBOLOGY_CODE128, 120, 380, 2, null)
        s.lineWrap(1, null)
        s.printQRCode(barcodePayload, 6, 1, null)
        s.lineWrap(1, null)
        s.printText("Keep this coupon. Present at exit.\n", null)
        s.lineWrap(3, null)
        s.cutpaper(null)
        true
    }

    fun printReceipt(
        companyName: String,
        couponNumber: String,
        vehicleType: String,
        category: String,
        entryDisplay: String,
        exitDisplay: String,
        durationText: String,
        billedHours: Int,
        hourlyRate: Double,
        amountUntaxed: Double,
        taxRate: Double,
        taxAmount: Double,
        grandTotal: Double,
        currencySymbol: String,
        paymentMethod: String,
        fonepayQrPayload: String?,
    ): Boolean = safePrint {
        val s = service ?: return@safePrint false
        fun money(v: Double) = "$currencySymbol ${"%.2f".format(v)}"

        s.setAlignment(ALIGN_CENTER, null)
        s.printTextWithFont("$companyName\n", null, 32f, null)
        s.printTextWithFont("PARKING RECEIPT\n", null, 24f, null)
        s.lineWrap(1, null)
        s.setAlignment(ALIGN_LEFT, null)
        s.printText("Coupon   : $couponNumber\n", null)
        s.printText("Vehicle  : $vehicleType\n", null)
        s.printText("Category : $category\n", null)
        s.printText("Entry    : $entryDisplay\n", null)
        s.printText("Exit     : $exitDisplay\n", null)
        s.printText("Duration : $durationText\n", null)
        s.lineWrap(1, null)
        s.printText("Billed hours : $billedHours\n", null)
        s.printText("Hourly rate  : ${money(hourlyRate)}\n", null)
        s.printText("Untaxed      : ${money(amountUntaxed)}\n", null)
        s.printText("VAT (${"%.1f".format(taxRate)}%, incl.): ${money(taxAmount)}\n", null)
        s.setFontSize(36f, null)
        s.printText("TOTAL: ${money(grandTotal)}\n", null)
        s.setFontSize(24f, null)
        s.printText("Paid by: $paymentMethod\n", null)
        s.lineWrap(1, null)
        if (fonepayQrPayload != null) {
            s.setAlignment(ALIGN_CENTER, null)
            s.printText("Scan to pay with FonePay\n", null)
            s.printQRCode(fonepayQrPayload, 8, 1, null)
            s.lineWrap(1, null)
        }
        s.setAlignment(ALIGN_CENTER, null)
        s.printText("** PAID **\n", null)
        s.printText("Thank you!\n", null)
        s.lineWrap(3, null)
        s.cutpaper(null)
        true
    }

    private inline fun safePrint(block: () -> Boolean): Boolean {
        return try {
            if (service == null) {
                Log.e(TAG, "Print requested but printer service is not connected")
                false
            } else {
                block()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Printer error", e)
            false
        }
    }
}

/**
 * Suspend helper kept separate from the class above so callers that just
 * want "wait until the printer is bound, or give up after a timeout" don't
 * need to manage a ServiceConnection themselves. Not currently used by the
 * activities (they call connect() in onCreate and check isReady before
 * printing) but kept here as it is often useful when adding a splash-screen
 * "connecting to printer..." step.
 */
suspend fun SunmiPrinterHelper.awaitReady(timeoutMillis: Long = 3000): Boolean =
    suspendCancellableCoroutine { cont ->
        val start = System.currentTimeMillis()
        val poll = object : Runnable {
            override fun run() {
                if (isReady) {
                    if (cont.isActive) cont.resume(true)
                } else if (System.currentTimeMillis() - start > timeoutMillis) {
                    if (cont.isActive) cont.resume(false)
                } else {
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this, 150)
                }
            }
        }
        poll.run()
    }
