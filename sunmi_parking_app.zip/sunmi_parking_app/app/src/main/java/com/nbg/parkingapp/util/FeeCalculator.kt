package com.nbg.parkingapp.util

import kotlin.math.max

/**
 * Mirrors, on the device, the exact fee formula implemented server-side in
 * `parking_management/models/parking_ticket.py` (`_compute_charges` /
 * `_round_billed_hours` / `_compute_tax`). Keep the two in sync -- if the
 * rate engine ever changes in Odoo, apply the same change here.
 *
 * Rounding rule: free minutes (from the chosen category) are deducted from
 * the parked duration first. Within the first hour, up to the vehicle
 * type's Grace Period is free and the rest of the first hour bills 1 hour.
 * From the second hour onward, up to (and including) the 30-minute mark
 * rounds DOWN to the current hour, past 30 minutes rounds UP to the next
 * one -- e.g. 4h10m -> 4h, 4h30m -> 4h, 4h31m -> 5h, 6h00m -> 6h (not 7h,
 * unlike a naive "round up on any excess" which is vulnerable to billing an
 * extra hour from a single second of clock drift on an exact multiple).
 * Tax is VAT-inclusive: the grand total is what the customer pays, VAT is
 * back-calculated for the receipt.
 */
object FeeCalculator {

    data class Result(
        val billedHours: Int,
        val grandTotal: Double,
        val amountUntaxed: Double,
        val taxAmount: Double,
    )

    /**
     * @param entryEpochMillis   entry time
     * @param exitEpochMillis    exit time (must be >= entry)
     * @param freeMinutes        from the chosen category (Club/Special/Other)
     * @param hourlyCharge       from the vehicle type's rate
     * @param taxRatePercent     e.g. 13.0 for 13% VAT, inclusive
     * @param graceMinutes       from the vehicle type's rate; free time within the first hour
     * @param isLostTicket       if true, ignores duration and bills lostTicketCharge instead
     * @param lostTicketCharge   flat fee applied when isLostTicket is true
     */
    fun compute(
        entryEpochMillis: Long,
        exitEpochMillis: Long,
        freeMinutes: Int,
        hourlyCharge: Double,
        taxRatePercent: Double,
        graceMinutes: Int = 0,
        isLostTicket: Boolean = false,
        lostTicketCharge: Double = 0.0,
    ): Result {
        val grandTotal: Double
        var billedHours = 0

        if (isLostTicket) {
            grandTotal = lostTicketCharge
        } else {
            val totalMinutes = max(0.0, (exitEpochMillis - entryEpochMillis) / 60000.0)
            val chargeableMinutes = max(0.0, totalMinutes - freeMinutes)
            billedHours = roundBilledHours(chargeableMinutes, graceMinutes)
            grandTotal = billedHours * hourlyCharge
        }

        val untaxed: Double
        val tax: Double
        if (taxRatePercent > 0) {
            untaxed = grandTotal / (1.0 + taxRatePercent / 100.0)
            tax = grandTotal - untaxed
        } else {
            untaxed = grandTotal
            tax = 0.0
        }

        return Result(
            billedHours = billedHours,
            grandTotal = round2(grandTotal),
            amountUntaxed = round2(untaxed),
            taxAmount = round2(tax),
        )
    }

    /** Mirrors ParkingTicket._round_billed_hours() in parking_ticket.py exactly. */
    private fun roundBilledHours(chargeableMinutes: Double, graceMinutes: Int): Int {
        if (chargeableMinutes <= 0) return 0
        val hours = (chargeableMinutes / 60.0).toInt()
        val remainder = chargeableMinutes - hours * 60.0
        if (hours == 0) return if (remainder <= graceMinutes) 0 else 1
        return if (remainder <= 30.0) hours else hours + 1
    }

    private fun round2(value: Double): Double = Math.round(value * 100.0) / 100.0
}
