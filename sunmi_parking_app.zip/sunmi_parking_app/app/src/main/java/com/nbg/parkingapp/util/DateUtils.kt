package com.nbg.parkingapp.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * All timestamps that leave this device (to Odoo, or into the barcode) are
 * in UTC, formatted the way Odoo's `fields.Datetime` expects: no 'T', no
 * timezone suffix, just "yyyy-MM-dd HH:mm:ss" interpreted as UTC. Timestamps
 * shown to a human (on screen or on a printed receipt) use the device's
 * local timezone instead.
 */
object DateUtils {

    private fun odooFormat(): SimpleDateFormat =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

    private fun displayFormat(): SimpleDateFormat =
        SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US)

    /** Current time, ready to send to Odoo. */
    fun nowForOdoo(): String = odooFormat().format(Date())

    /** Convert an epoch-millis timestamp to the string Odoo expects. */
    fun toOdooString(epochMillis: Long): String = odooFormat().format(Date(epochMillis))

    /** Human-friendly local time, for the screen and the printed receipt. */
    fun toDisplayString(epochMillis: Long): String = displayFormat().format(Date(epochMillis))

    /** Compact form used inside the coupon barcode: whole seconds since epoch. */
    fun toEpochSeconds(epochMillis: Long): Long = epochMillis / 1000L

    fun fromEpochSeconds(epochSeconds: Long): Long = epochSeconds * 1000L
}
