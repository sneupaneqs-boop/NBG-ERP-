package com.nbg.parkingapp.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

/** Local device settings: which Odoo server, which key, which gate. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.getSharedPreferences("parking_app_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    var serverUrl: String
        get() = sp.getString(KEY_SERVER_URL, "") ?: ""
        set(value) = sp.edit().putString(KEY_SERVER_URL, value.trimEnd('/')).apply()

    var apiKey: String
        get() = sp.getString(KEY_API_KEY, "") ?: ""
        set(value) = sp.edit().putString(KEY_API_KEY, value).apply()

    var gateName: String
        get() = sp.getString(KEY_GATE_NAME, "Gate 1") ?: "Gate 1"
        set(value) = sp.edit().putString(KEY_GATE_NAME, value).apply()

    val isConfigured: Boolean
        get() = serverUrl.isNotBlank() && apiKey.isNotBlank()

    var cachedConfig: RemoteConfig?
        get() = sp.getString(KEY_CONFIG_JSON, null)?.let {
            runCatching { gson.fromJson(it, RemoteConfig::class.java) }.getOrNull()
        }
        set(value) {
            sp.edit().putString(KEY_CONFIG_JSON, value?.let { gson.toJson(it) }).apply()
        }

    var lastConfigSyncMillis: Long
        get() = sp.getLong(KEY_CONFIG_SYNCED_AT, 0L)
        set(value) = sp.edit().putLong(KEY_CONFIG_SYNCED_AT, value).apply()

    companion object {
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_GATE_NAME = "gate_name"
        private const val KEY_CONFIG_JSON = "cached_config_json"
        private const val KEY_CONFIG_SYNCED_AT = "cached_config_synced_at"
    }
}
