package com.nbg.parkingapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * The local, offline-first record of one parking session. Created the
 * instant a coupon is printed at entry; updated the instant a bill is
 * calculated and paid at exit. `syncedEntry` / `syncedExitPay` track what
 * has and hasn't reached Odoo yet -- [com.nbg.parkingapp.sync.SyncWorker]
 * keeps retrying anything that's still false.
 *
 * Nothing here is ever deleted by the sync process; this table doubles as
 * the device's own permanent local log, so staff can always look up a past
 * ticket even if the network was down for hours.
 */
@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val couponNumber: String,

    val vehicleTypeCode: String,
    val entryEpochMillis: Long,
    val gateName: String,

    // Filled in at exit.
    var categoryName: String? = null,
    var freeMinutes: Int = 0,
    var exitEpochMillis: Long? = null,
    var billedHours: Int = 0,
    var hourlyCharge: Double = 0.0,
    var grandTotal: Double = 0.0,
    var amountUntaxed: Double = 0.0,
    var taxAmount: Double = 0.0,
    var isLostTicket: Boolean = false,

    // Filled in at payment.
    var paymentMethod: String? = null,   // "cash" | "fonepay"
    var paymentReference: String? = null,
    var paymentEpochMillis: Long? = null,
    var isPaid: Boolean = false,

    // Sync bookkeeping -- never touched by the UI, only by SyncWorker.
    var syncedEntry: Boolean = false,
    var syncedExitPay: Boolean = false,
    var syncAttempts: Int = 0,
    var lastSyncError: String? = null,
)
