package com.nbg.parkingapp.api

/** Request/response bodies matching parking_management/controllers/main.py exactly. */

data class PingRequest(val api_key: String)

data class ConfigRequest(val api_key: String)

data class EntryRequest(
    val api_key: String,
    val coupon_number: String,
    val vehicle_type: String,
    val entry_time: String,
    val gate_number: String,
)

data class ExitRequest(
    val api_key: String,
    val code: String,
    val category: String,
    val exit_time: String,
    val gate_number: String,
)

data class PayRequest(
    val api_key: String,
    val code: String,
    val method: String,
    val reference: String? = null,
    val device_txn_id: String,
    val payment_date: String,
    val amount: Double,
)

data class LostRequest(
    val api_key: String,
    val code: String,
    val exit_time: String,
)

data class ApiEnvelope<T>(
    val success: Boolean,
    val data: T? = null,
    val error: String? = null,
)

data class TicketDto(
    val ticket: String,
    val coupon_number: String,
    val barcode: String,
    val state: String,
    val gate_number: String,
    val vehicle_number: String,
    val vehicle_type: String,
    val category: String,
    val free_minutes: Int,
    val entry_time: String?,
    val exit_time: String?,
    val duration: String,
    val billed_hours: Int,
    val hourly_rate: Double,
    val currency: String,
    val tax_rate: Double,
    val amount_total: Double,
    val discount: Double,
    val amount_untaxed: Double,
    val tax_amount: Double,
    val grand_total: Double,
    val amount_paid: Double,
    val amount_due: Double,
    val is_paid: Boolean,
    val is_lost_ticket: Boolean,
    val qr_code_base64: String?,
    val fonepay_qr_base64: String?,
)
