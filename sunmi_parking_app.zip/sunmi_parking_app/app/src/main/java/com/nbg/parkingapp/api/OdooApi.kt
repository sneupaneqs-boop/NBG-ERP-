package com.nbg.parkingapp.api

import com.nbg.parkingapp.data.RemoteConfig
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

/** Retrofit interface for parking_management's device API (see main.py). */
interface OdooApi {

    @POST("parking/api/v1/ping")
    suspend fun ping(@Body body: PingRequest): Response<ApiEnvelope<Unit>>

    @POST("parking/api/v1/config")
    suspend fun getConfig(@Body body: ConfigRequest): Response<ApiEnvelope<RemoteConfig>>

    @POST("parking/api/v1/entry")
    suspend fun entry(@Body body: EntryRequest): Response<ApiEnvelope<TicketDto>>

    @POST("parking/api/v1/exit")
    suspend fun exit(@Body body: ExitRequest): Response<ApiEnvelope<TicketDto>>

    @POST("parking/api/v1/pay")
    suspend fun pay(@Body body: PayRequest): Response<ApiEnvelope<TicketDto>>

    @POST("parking/api/v1/lost")
    suspend fun lost(@Body body: LostRequest): Response<ApiEnvelope<TicketDto>>
}
