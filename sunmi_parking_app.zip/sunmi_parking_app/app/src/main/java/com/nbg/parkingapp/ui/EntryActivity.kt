package com.nbg.parkingapp.ui

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nbg.parkingapp.R
import com.nbg.parkingapp.data.AppDatabase
import com.nbg.parkingapp.data.Prefs
import com.nbg.parkingapp.data.RemoteConfig
import com.nbg.parkingapp.data.TicketEntity
import com.nbg.parkingapp.print.SunmiPrinterHelper
import com.nbg.parkingapp.sync.SyncManager
import com.nbg.parkingapp.util.DateUtils
import com.nbg.parkingapp.util.IdGenerator
import kotlinx.coroutines.launch

/**
 * Entry flow: pick Bike or Car -> a coupon number + barcode payload is
 * generated **entirely on-device** (entry time + vehicle type are encoded
 * directly into the barcode) -> tap Print. No network call is needed to get
 * this far; the ticket is saved locally the moment Print is pressed and
 * synced to Odoo in the background whenever a connection is available.
 */
class EntryActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var printer: SunmiPrinterHelper
    private var selectedTypeCode: String? = null
    private var pendingCouponNumber: String? = null
    private var pendingEntryMillis: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry)
        prefs = Prefs(this)
        printer = SunmiPrinterHelper(this).also { it.connect() }

        val config = prefs.cachedConfig
        val bikeButton = findViewById<Button>(R.id.bikeButton)
        val carButton = findViewById<Button>(R.id.carButton)

        bikeButton.setOnClickListener { onTypeSelected("BIKE", config) }
        carButton.setOnClickListener { onTypeSelected("CAR", config) }

        findViewById<Button>(R.id.printButton).setOnClickListener { onPrintClicked(config) }
        findViewById<Button>(R.id.cancelButton).setOnClickListener { resetToTypeSelection() }
    }

    override fun onDestroy() {
        super.onDestroy()
        printer.disconnect()
    }

    private fun onTypeSelected(code: String, config: RemoteConfig?) {
        if (config == null) {
            Toast.makeText(this, "Rates not loaded yet. Open Settings and reconnect.", Toast.LENGTH_LONG).show()
            return
        }
        selectedTypeCode = code
        pendingCouponNumber = IdGenerator.newCouponNumber(prefs.gateName)
        pendingEntryMillis = System.currentTimeMillis()

        val label = config.vehicleType(code)?.name ?: code
        findViewById<TextView>(R.id.couponNumberText).text = "Coupon: ${pendingCouponNumber}"
        findViewById<TextView>(R.id.vehicleTypeText).text = "Vehicle type: $label"
        findViewById<TextView>(R.id.entryTimeText).text =
            "Entry time: ${DateUtils.toDisplayString(pendingEntryMillis)}"

        findViewById<LinearLayout>(R.id.typeSelectionGroup).visibility = android.view.View.GONE
        findViewById<LinearLayout>(R.id.confirmGroup).visibility = android.view.View.VISIBLE
    }

    private fun resetToTypeSelection() {
        selectedTypeCode = null
        pendingCouponNumber = null
        findViewById<LinearLayout>(R.id.confirmGroup).visibility = android.view.View.GONE
        findViewById<LinearLayout>(R.id.typeSelectionGroup).visibility = android.view.View.VISIBLE
    }

    private fun onPrintClicked(config: RemoteConfig?) {
        val typeCode = selectedTypeCode ?: return
        val coupon = pendingCouponNumber ?: return
        if (config == null) return

        val payload = barcodePayload(coupon, typeCode, pendingEntryMillis)
        val typeName = config.vehicleType(typeCode)?.name ?: typeCode
        val entryDisplay = DateUtils.toDisplayString(pendingEntryMillis)

        // Save FIRST: a printer jam must never lose a real vehicle entry.
        lifecycleScope.launch {
            val entity = TicketEntity(
                couponNumber = coupon,
                vehicleTypeCode = typeCode,
                entryEpochMillis = pendingEntryMillis,
                gateName = prefs.gateName,
            )
            AppDatabase.get(this@EntryActivity).ticketDao().upsert(entity)
            SyncManager.syncNow(this@EntryActivity)

            val printed = printer.printCoupon(
                companyName = config.company_name,
                vehicleType = typeName,
                couponNumber = coupon,
                entryDisplay = entryDisplay,
                gateName = prefs.gateName,
                barcodePayload = payload,
            )

            if (printed) {
                Toast.makeText(this@EntryActivity, "Coupon printed", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this@EntryActivity,
                    "Printer error -- the entry was still saved. Write \"$coupon\" on a blank slip.",
                    Toast.LENGTH_LONG,
                ).show()
            }
            finish()
        }
    }

    companion object {
        /** Format version tag lets a future app update change the payload
         *  layout without breaking coupons already printed and in
         *  customers' pockets. */
        fun barcodePayload(coupon: String, vehicleTypeCode: String, entryEpochMillis: Long): String {
            val epochSeconds = DateUtils.toEpochSeconds(entryEpochMillis)
            return "PK1|$coupon|$vehicleTypeCode|$epochSeconds"
        }
    }
}
