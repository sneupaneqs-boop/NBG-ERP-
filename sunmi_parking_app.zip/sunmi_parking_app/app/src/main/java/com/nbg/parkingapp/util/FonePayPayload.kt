package com.nbg.parkingapp.util

/**
 * MUST stay identical to the format built server-side in
 * `parking_management/models/fonepay_connector.py` (`build_payload`), so a
 * QR generated offline on the device looks exactly like one Odoo would
 * generate for the same ticket. This is a placeholder payload (not a real
 * FonePay/NepalQR string) until the live FonePay Dynamic-QR API is wired
 * into both sides.
 */
object FonePayPayload {
    fun build(merchantCode: String, amount: Double, reference: String): String {
        val merchant = merchantCode.ifBlank { "FONEPAY-MERCHANT" }
        return "FONEPAY|MERCHANT:%s|AMOUNT:%.2f|REF:%s".format(merchant, amount, reference)
    }
}
