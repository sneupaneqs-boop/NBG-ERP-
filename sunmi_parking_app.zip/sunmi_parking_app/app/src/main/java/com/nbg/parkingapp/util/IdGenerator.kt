package com.nbg.parkingapp.util

import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Generates coupon numbers that are unique per device without ever needing
 * to ask the server for the "next" number (the whole point of working
 * offline). Format: "<GATE>-<yyMMddHHmmss><2-digit counter>", e.g.
 * "GATE1-25070911223001". The counter guards against two coupons printed
 * within the same second.
 */
object IdGenerator {

    private val counter = AtomicInteger(0)

    fun newCouponNumber(gateName: String): String {
        val safeGate = gateName.ifBlank { "GATE" }
            .uppercase(Locale.US)
            .replace(Regex("[^A-Z0-9]"), "")
            .ifBlank { "GATE" }
        val ts = java.text.SimpleDateFormat("yyMMddHHmmss", Locale.US).format(java.util.Date())
        val seq = counter.updateAndGet { (it + 1) % 100 }
        return "%s-%s%02d".format(safeGate, ts, seq)
    }

    /** Idempotency key for a payment, derived from the ticket's own coupon number. */
    fun paymentTxnId(couponNumber: String): String = "$couponNumber-PAY"
}
