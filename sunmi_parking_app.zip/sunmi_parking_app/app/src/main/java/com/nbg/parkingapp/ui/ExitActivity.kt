package com.nbg.parkingapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nbg.parkingapp.R
import com.nbg.parkingapp.data.AppDatabase
import com.nbg.parkingapp.data.Prefs
import com.nbg.parkingapp.data.RemoteConfig
import com.nbg.parkingapp.data.TicketEntity
import com.nbg.parkingapp.print.SunmiPrinterHelper
import com.nbg.parkingapp.scan.CameraScannerActivity
import com.nbg.parkingapp.scan.HardwareScanReceiver
import com.nbg.parkingapp.sync.SyncManager
import com.nbg.parkingapp.util.DateUtils
import com.nbg.parkingapp.util.FeeCalculator
import com.nbg.parkingapp.util.FonePayPayload
import com.nbg.parkingapp.util.IdGenerator
import com.nbg.parkingapp.util.QrGenerator
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Exit flow. The barcode alone is self-contained (see
 * [EntryActivity.barcodePayload]) so a normal scan needs **no** database or
 * network lookup: vehicle type and entry time are decoded straight from
 * the code, category is chosen on this screen, the bill is calculated
 * on-device, and the receipt (with a FonePay QR for the exact amount)
 * prints immediately. Everything is queued for background sync the moment
 * payment is confirmed.
 */
class ExitActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var printer: SunmiPrinterHelper
    private var config: RemoteConfig? = null

    // Current ticket being processed.
    private var couponNumber: String? = null
    private var vehicleTypeCode: String? = null
    private var entryEpochMillis: Long = 0L
    private var isLostMode: Boolean = false
    private var manualTypeSelection: String? = null

    // After category is chosen.
    private var categoryName: String? = null
    private var freeMinutes: Int = 0
    private var feeResult: FeeCalculator.Result? = null

    private val scanReceiver = HardwareScanReceiver { code -> runOnUiThread { onCodeScanned(code) } }

    private val cameraScanLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data?.getStringExtra(CameraScannerActivity.RESULT_TEXT)
            if (!text.isNullOrBlank()) onCodeScanned(text)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exit)
        prefs = Prefs(this)
        config = prefs.cachedConfig
        printer = SunmiPrinterHelper(this).also { it.connect() }

        findViewById<Button>(R.id.cameraScanButton).setOnClickListener {
            cameraScanLauncher.launch(Intent(this, CameraScannerActivity::class.java))
        }
        findViewById<Button>(R.id.enterManuallyButton).setOnClickListener { showManualEntry(lost = false) }
        findViewById<Button>(R.id.lostTicketButton).setOnClickListener { showManualEntry(lost = true) }
        findViewById<Button>(R.id.manualCancelButton).setOnClickListener { showStep(R.id.scanGroup) }
        findViewById<Button>(R.id.manualBikeButton).setOnClickListener { onManualTypePicked("BIKE") }
        findViewById<Button>(R.id.manualCarButton).setOnClickListener { onManualTypePicked("CAR") }
        findViewById<Button>(R.id.manualContinueButton).setOnClickListener { onManualContinue() }

        findViewById<Button>(R.id.cashButton).setOnClickListener { onPaymentChosen("cash") }
        findViewById<Button>(R.id.fonepayButton).setOnClickListener { onPaymentChosen("fonepay") }
        findViewById<Button>(R.id.confirmFonepayButton).setOnClickListener { finishPayment("fonepay") }

        findViewById<Button>(R.id.doneButton).setOnClickListener { finish() }
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        if (config == null) {
            Toast.makeText(this, "Rates not loaded. Open Settings and reconnect.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(scanReceiver, HardwareScanReceiver.intentFilter())
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(scanReceiver) }
    }

    override fun onDestroy() {
        super.onDestroy()
        printer.disconnect()
    }

    // ------------------------------------------------------------------
    // Step 1: scan
    // ------------------------------------------------------------------
    private fun onCodeScanned(payload: String) {
        // Expected: PK1|<coupon>|<vehicleTypeCode>|<entryEpochSeconds>
        val parts = payload.trim().split("|")
        if (parts.size != 4 || parts[0] != "PK1") {
            Toast.makeText(this, "Unrecognised code -- try Enter Manually.", Toast.LENGTH_LONG).show()
            return
        }
        val epochSeconds = parts[3].toLongOrNull()
        if (epochSeconds == null) {
            Toast.makeText(this, "Could not read the entry time from this code.", Toast.LENGTH_LONG).show()
            return
        }
        couponNumber = parts[1]
        vehicleTypeCode = parts[2]
        entryEpochMillis = DateUtils.fromEpochSeconds(epochSeconds)
        isLostMode = false
        showCategoryStep()
    }

    // ------------------------------------------------------------------
    // Manual fallback (damaged barcode, or lost ticket)
    // ------------------------------------------------------------------
    private fun showManualEntry(lost: Boolean) {
        isLostMode = lost
        manualTypeSelection = null
        findViewById<TextView>(R.id.manualEntryTitle).text =
            if (lost) "Lost Ticket -- select vehicle type" else "Enter details from the coupon"
        findViewById<EditText>(R.id.manualCodeInput).hint =
            if (lost) "Coupon number (optional)" else "Coupon number (required, printed on the coupon)"
        findViewById<LinearLayout>(R.id.manualEntryTimeRow).visibility =
            if (lost) View.GONE else View.VISIBLE
        showStep(R.id.manualEntryGroup)
    }

    private fun onManualTypePicked(code: String) {
        manualTypeSelection = code
        if (isLostMode) {
            val cfg = config ?: return
            val vt = cfg.vehicleType(code)
            couponNumber = findViewById<EditText>(R.id.manualCodeInput).text.toString().trim()
                .ifBlank { IdGenerator.newCouponNumber(prefs.gateName) }
            vehicleTypeCode = code
            entryEpochMillis = System.currentTimeMillis()
            feeResult = FeeCalculator.compute(
                entryEpochMillis = entryEpochMillis,
                exitEpochMillis = System.currentTimeMillis(),
                freeMinutes = 0,
                hourlyCharge = 0.0,
                taxRatePercent = cfg.tax_rate,
                isLostTicket = true,
                lostTicketCharge = vt?.lost_ticket_charge ?: 0.0,
            )
            categoryName = null
            freeMinutes = 0
            showBillStep()
        } else {
            Toast.makeText(this, "Selected ${if (code == "BIKE") "Bike" else "Car"}. Now enter the time and tap Continue.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onManualContinue() {
        if (isLostMode) return // Lost mode proceeds directly from onManualTypePicked.

        val code = findViewById<EditText>(R.id.manualCodeInput).text.toString().trim()
        val type = manualTypeSelection
        val timeText = findViewById<EditText>(R.id.manualEntryTimeInput).text.toString().trim()

        if (code.isBlank()) {
            Toast.makeText(this, "Please type the coupon number printed on the paper.", Toast.LENGTH_LONG).show()
            return
        }
        if (type == null) {
            Toast.makeText(this, "Please select Bike or Car.", Toast.LENGTH_SHORT).show()
            return
        }
        val parsedMillis = parseDisplayDateTime(timeText)
        if (parsedMillis == null) {
            Toast.makeText(this, "Entry time format should be dd/MM/yyyy hh:mm AM/PM (as printed).", Toast.LENGTH_LONG).show()
            return
        }

        couponNumber = code
        vehicleTypeCode = type
        entryEpochMillis = parsedMillis
        isLostMode = false
        showCategoryStep()
    }

    private fun parseDisplayDateTime(text: String): Long? = runCatching {
        SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US).parse(text)?.time
    }.getOrNull()

    // ------------------------------------------------------------------
    // Step 2: category
    // ------------------------------------------------------------------
    private fun showCategoryStep() {
        val cfg = config ?: return
        val vt = cfg.vehicleType(vehicleTypeCode.orEmpty())
        findViewById<TextView>(R.id.ticketSummaryText).text =
            "Coupon: $couponNumber\nVehicle: ${vt?.name ?: vehicleTypeCode}\n" +
                "Entry: ${DateUtils.toDisplayString(entryEpochMillis)}"

        val container = findViewById<LinearLayout>(R.id.categoryButtonsContainer)
        container.removeAllViews()
        for (cat in cfg.categories) {
            val button = Button(this).apply {
                text = if (cat.free_minutes > 0) "${cat.name} (${cat.free_minutes} min free)" else cat.name
                setOnClickListener { onCategoryPicked(cat.name, cat.free_minutes) }
                setPadding(24, 24, 24, 24)
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            )
            params.bottomMargin = 16
            container.addView(button, params)
        }
        showStep(R.id.categoryGroup)
    }

    private fun onCategoryPicked(name: String, minutes: Int) {
        val cfg = config ?: return
        val vt = cfg.vehicleType(vehicleTypeCode.orEmpty())
        categoryName = name
        freeMinutes = minutes
        feeResult = FeeCalculator.compute(
            entryEpochMillis = entryEpochMillis,
            exitEpochMillis = System.currentTimeMillis(),
            freeMinutes = minutes,
            hourlyCharge = vt?.hourly_charge ?: 0.0,
            taxRatePercent = cfg.tax_rate,
            graceMinutes = vt?.grace_period ?: 0,
        )
        showBillStep()
    }

    // ------------------------------------------------------------------
    // Step 3: bill + payment method
    // ------------------------------------------------------------------
    private fun showBillStep() {
        val cfg = config ?: return
        val fee = feeResult ?: return
        val sym = cfg.currency_symbol.ifBlank { cfg.currency }

        val details = StringBuilder()
        if (isLostMode) {
            details.append("Lost ticket charge\n")
        } else {
            val durationMin = (System.currentTimeMillis() - entryEpochMillis) / 60000
            details.append("Duration: ${durationMin / 60}h ${durationMin % 60}m\n")
            details.append("Billed hours: ${fee.billedHours}\n")
        }
        details.append("Untaxed: $sym ${"%.2f".format(fee.amountUntaxed)}\n")
        details.append("VAT (${"%.1f".format(cfg.tax_rate)}%, incl.): $sym ${"%.2f".format(fee.taxAmount)}")
        findViewById<TextView>(R.id.billDetailsText).text = details.toString()
        findViewById<TextView>(R.id.billTotalText).text = "TOTAL: $sym ${"%.2f".format(fee.grandTotal)}"

        showStep(R.id.billGroup)
    }

    private fun onPaymentChosen(method: String) {
        if (method == "cash") {
            finishPayment("cash")
        } else {
            val cfg = config ?: return
            val fee = feeResult ?: return
            val payload = FonePayPayload.build(cfg.fonepay_merchant_code, fee.grandTotal, couponNumber.orEmpty())
            val bitmap = QrGenerator.generate(payload)
            findViewById<ImageView>(R.id.fonepayQrImage).setImageBitmap(bitmap)
            showStep(R.id.fonepayGroup)
        }
    }

    // ------------------------------------------------------------------
    // Step 4/5: confirm, save, sync, print
    // ------------------------------------------------------------------
    private fun finishPayment(method: String) {
        val cfg = config ?: return
        val fee = feeResult ?: return
        val coupon = couponNumber ?: return
        val vt = cfg.vehicleType(vehicleTypeCode.orEmpty())
        val sym = cfg.currency_symbol.ifBlank { cfg.currency }
        val reference = if (method == "fonepay") {
            findViewById<EditText>(R.id.fonepayReferenceInput).text.toString().trim().ifBlank { null }
        } else null
        val paymentMillis = System.currentTimeMillis()
        val exitMillis = System.currentTimeMillis()

        lifecycleScope.launch {
            val dao = AppDatabase.get(this@ExitActivity).ticketDao()
            val existing = dao.findByCoupon(coupon)
            val entity = (existing ?: TicketEntity(
                couponNumber = coupon,
                vehicleTypeCode = vehicleTypeCode.orEmpty(),
                entryEpochMillis = entryEpochMillis,
                gateName = prefs.gateName,
                syncedEntry = false,
            )).apply {
                categoryName = this@ExitActivity.categoryName
                freeMinutes = this@ExitActivity.freeMinutes
                exitEpochMillis = exitMillis
                billedHours = fee.billedHours
                hourlyCharge = vt?.hourly_charge ?: 0.0
                grandTotal = fee.grandTotal
                amountUntaxed = fee.amountUntaxed
                taxAmount = fee.taxAmount
                isLostTicket = isLostMode
                paymentMethod = method
                paymentReference = reference
                paymentEpochMillis = paymentMillis
                isPaid = true
            }
            dao.upsert(entity)
            SyncManager.syncNow(this@ExitActivity)

            val fonepayPayload = if (method == "fonepay") {
                FonePayPayload.build(cfg.fonepay_merchant_code, fee.grandTotal, coupon)
            } else null

            val printed = printer.printReceipt(
                companyName = cfg.company_name,
                couponNumber = coupon,
                vehicleType = vt?.name ?: vehicleTypeCode.orEmpty(),
                category = categoryName ?: "Lost Ticket",
                entryDisplay = DateUtils.toDisplayString(entryEpochMillis),
                exitDisplay = DateUtils.toDisplayString(exitMillis),
                durationText = if (isLostMode) "--" else "${fee.billedHours}h billed",
                billedHours = fee.billedHours,
                hourlyRate = vt?.hourly_charge ?: 0.0,
                amountUntaxed = fee.amountUntaxed,
                taxRate = cfg.tax_rate,
                taxAmount = fee.taxAmount,
                grandTotal = fee.grandTotal,
                currencySymbol = sym,
                paymentMethod = if (method == "cash") "Cash" else "FonePay",
                fonepayQrPayload = fonepayPayload,
            )
            if (!printed) {
                Toast.makeText(this@ExitActivity, "Printer error -- payment was still saved.", Toast.LENGTH_LONG).show()
            }
            showStep(R.id.doneGroup)
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private fun showStep(visibleGroupId: Int) {
        val allGroups = listOf(
            R.id.scanGroup, R.id.manualEntryGroup, R.id.categoryGroup,
            R.id.billGroup, R.id.fonepayGroup, R.id.doneGroup,
        )
        for (id in allGroups) {
            findViewById<View>(id).visibility = if (id == visibleGroupId) View.VISIBLE else View.GONE
        }
    }
}
