package com.nbg.parkingapp.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nbg.parkingapp.api.ApiClient
import com.nbg.parkingapp.api.EntryRequest
import com.nbg.parkingapp.api.ExitRequest
import com.nbg.parkingapp.api.PayRequest
import com.nbg.parkingapp.data.AppDatabase
import com.nbg.parkingapp.data.Prefs
import com.nbg.parkingapp.util.DateUtils
import com.nbg.parkingapp.util.IdGenerator

/**
 * Pushes every not-yet-synced local ticket (and its exit/payment, once
 * present) to Odoo. Safe to run as often as you like: every write endpoint
 * on the Odoo side is idempotent, so re-sending something that already
 * made it through just gets the existing record back, never a duplicate.
 *
 * Runs periodically via [SyncManager] and can also be triggered immediately
 * right after a coupon is printed or a payment is taken, so the normal case
 * (network is fine) syncs within a second or two -- offline is the
 * fallback path, not the common one.
 */
class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "SyncWorker"
        const val UNIQUE_PERIODIC_NAME = "parking_sync_periodic"
        const val UNIQUE_ONE_SHOT_NAME = "parking_sync_now"
    }

    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        if (!prefs.isConfigured) return Result.success()

        val api = ApiClient.build(prefs) ?: return Result.retry()
        val dao = AppDatabase.get(applicationContext).ticketDao()
        val pending = dao.findUnsynced()
        if (pending.isEmpty()) return Result.success()

        var anyFailure = false

        for (ticket in pending) {
            try {
                if (!ticket.syncedEntry) {
                    val resp = api.entry(
                        EntryRequest(
                            api_key = prefs.apiKey,
                            coupon_number = ticket.couponNumber,
                            vehicle_type = ticket.vehicleTypeCode,
                            entry_time = DateUtils.toOdooString(ticket.entryEpochMillis),
                            gate_number = ticket.gateName,
                        )
                    )
                    if (resp.isSuccessful && resp.body()?.success == true) {
                        ticket.syncedEntry = true
                        ticket.lastSyncError = null
                    } else {
                        throw RuntimeException("entry sync failed: HTTP ${resp.code()} ${resp.errorBody()?.string()}")
                    }
                }

                // Exit + payment can only sync once entry has (Odoo needs the
                // ticket to exist first), and only once the exit has actually
                // been calculated locally (exitEpochMillis != null).
                if (ticket.syncedEntry && !ticket.syncedExitPay && ticket.exitEpochMillis != null) {
                    if (ticket.isLostTicket) {
                        val lostResp = api.lost(
                            com.nbg.parkingapp.api.LostRequest(
                                api_key = prefs.apiKey,
                                code = ticket.couponNumber,
                                exit_time = DateUtils.toOdooString(ticket.exitEpochMillis!!),
                            )
                        )
                        if (!lostResp.isSuccessful || lostResp.body()?.success != true) {
                            throw RuntimeException("lost-ticket sync failed: HTTP ${lostResp.code()}")
                        }
                    } else {
                        val exitResp = api.exit(
                            ExitRequest(
                                api_key = prefs.apiKey,
                                code = ticket.couponNumber,
                                category = ticket.categoryName.orEmpty(),
                                exit_time = DateUtils.toOdooString(ticket.exitEpochMillis!!),
                                gate_number = ticket.gateName,
                            )
                        )
                        if (!exitResp.isSuccessful || exitResp.body()?.success != true) {
                            throw RuntimeException("exit sync failed: HTTP ${exitResp.code()}")
                        }
                    }

                    if (ticket.isPaid) {
                        val payResp = api.pay(
                            PayRequest(
                                api_key = prefs.apiKey,
                                code = ticket.couponNumber,
                                method = ticket.paymentMethod ?: "cash",
                                reference = ticket.paymentReference,
                                device_txn_id = IdGenerator.paymentTxnId(ticket.couponNumber),
                                payment_date = DateUtils.toOdooString(
                                    ticket.paymentEpochMillis ?: ticket.exitEpochMillis!!
                                ),
                                amount = ticket.grandTotal,
                            )
                        )
                        if (!payResp.isSuccessful || payResp.body()?.success != true) {
                            throw RuntimeException("payment sync failed: HTTP ${payResp.code()}")
                        }
                    }
                    ticket.syncedExitPay = true
                    ticket.lastSyncError = null
                }

                dao.update(ticket)
            } catch (e: Exception) {
                Log.w(TAG, "Sync failed for ${ticket.couponNumber}, will retry later", e)
                ticket.syncAttempts += 1
                ticket.lastSyncError = e.message
                dao.update(ticket)
                anyFailure = true
            }
        }

        return if (anyFailure) Result.retry() else Result.success()
    }
}
