package com.nbg.parkingapp

import android.app.Application
import com.nbg.parkingapp.sync.SyncManager

class ParkingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SyncManager.schedulePeriodic(this)
    }
}
