package com.nbg.parkingapp.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nbg.parkingapp.R
import com.nbg.parkingapp.data.AppDatabase
import com.nbg.parkingapp.data.Prefs
import com.nbg.parkingapp.sync.SyncManager
import kotlinx.coroutines.launch

/** Home screen: two big buttons, ENTRY and EXIT, plus a live sync-pending indicator. */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (!prefs.isConfigured) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        findViewById<android.widget.TextView>(R.id.gateLabel).text = prefs.gateName

        findViewById<android.widget.Button>(R.id.entryButton).setOnClickListener {
            startActivity(Intent(this, EntryActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.exitButton).setOnClickListener {
            startActivity(Intent(this, ExitActivity::class.java))
        }
        findViewById<android.widget.ImageButton>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }

        observePendingSync()
        SyncManager.syncNow(this)
    }

    override fun onResume() {
        super.onResume()
        if (::prefs.isInitialized) {
            findViewById<android.widget.TextView>(R.id.gateLabel)?.text = prefs.gateName
            SyncManager.syncNow(this)
        }
    }

    private fun observePendingSync() {
        val dao = AppDatabase.get(this).ticketDao()
        lifecycleScope.launch {
            dao.pendingCount().collect { count ->
                val label = findViewById<android.widget.TextView>(R.id.syncStatus) ?: return@collect
                if (count == 0) {
                    label.text = "✔ Synced"
                    label.setTextColor(getColor(R.color.brand_green))
                } else {
                    label.text = "⏳ $count pending"
                    label.setTextColor(getColor(R.color.brand_orange))
                }
            }
        }
    }
}
