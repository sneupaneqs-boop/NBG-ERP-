package com.nbg.parkingapp.scan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log

/**
 * Listens for the Sunmi device's built-in scan engine (the hardware
 * scan-trigger button/key). Register in `onResume`, unregister in
 * `onPause` from whichever Activity needs scan input (ExitActivity).
 *
 * ON-DEVICE VERIFICATION NEEDED: Sunmi scan-equipped terminals broadcast
 * the decoded text when a scan succeeds, but the exact broadcast **action**
 * and the extra **key** the text is stored under can differ by firmware
 * generation. This class listens for every action/key combination commonly
 * seen across Sunmi's product line so it has the best chance of working
 * out of the box; if a real scan on this device still doesn't trigger
 * [onScan], run `adb logcat | grep ScanReceiver` while pressing the
 * hardware scan button to see what intent actually arrives, then add that
 * action/extra pair to the lists below.
 */
class HardwareScanReceiver(private val onScan: (String) -> Unit) : BroadcastReceiver() {

    companion object {
        private const val TAG = "ScanReceiver"

        // Broadcast actions seen across different Sunmi scan-engine models.
        val CANDIDATE_ACTIONS = listOf(
            "com.sunmi.scanner.ACTION_DATA_CODE_RECEIVED",
            "com.sunmi.scan.action.SCAN_RESULT",
        )

        // Extra keys the scanned text has been observed under.
        private val CANDIDATE_EXTRAS = listOf("data", "SCAN_BARCODE1", "barcode", "value")

        fun intentFilter(): IntentFilter {
            val filter = IntentFilter()
            CANDIDATE_ACTIONS.forEach { filter.addAction(it) }
            return filter
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        Log.i(TAG, "Scan broadcast received: action=${intent.action} extras=${intent.extras?.keySet()}")
        for (key in CANDIDATE_EXTRAS) {
            val value = intent.getStringExtra(key)
            if (!value.isNullOrBlank()) {
                onScan(value.trim())
                return
            }
        }
        Log.w(TAG, "Scan broadcast had none of the expected extras -- see class doc comment")
    }
}
