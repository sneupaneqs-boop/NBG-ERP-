// Sunmi's public "InnerPrinter" AIDL interface.
//
// This file is part of Sunmi's officially published Printer SDK
// (package woyou.aidlservice.jiuiv5) and is copied verbatim -- every app
// that talks to a Sunmi device's built-in thermal printer binds to this
// exact interface. Only the subset of methods this app actually calls is
// declared; that is fine, AIDL only needs to match the *server* side
// (already installed on the device), not the other way round.
//
// NOTE for whoever builds this: if `aidl` complains this file conflicts
// with a copy already bundled in a newer sunmi-printerservice AAR, delete
// this file and add that AAR as a dependency instead -- same interface,
// just distributed differently across Sunmi SDK versions.
package woyou.aidlservice.jiuiv5;

interface IWoyouService {
    void printText(String text, in Bundle extras);
    void printTextWithFont(String text, String typeface, float fontsize, in Bundle extras);
    void setAlignment(int alignment, in Bundle extras);
    void setFontSize(float fontsize, in Bundle extras);
    void setFontName(String typeface, in Bundle extras);
    void printBarCode(String data, int symbology, int height, int width, int textPosition, in Bundle extras);
    void printQRCode(String data, int modulesize, int errorlevel, in Bundle extras);
    void printOriginalText(String text, in Bundle extras);
    void printColumnsText(in String[] colsTextArr, in int[] colsWidthArr, in int[] colsAlign, in Bundle extras);
    void lineWrap(int n, in Bundle extras);
    void sendRAWData(in byte[] data, in Bundle extras);
    void enterPrinterBuffer(boolean clean);
    void exitPrinterBuffer(boolean commit);
    void commitPrinterBuffer();
    int getPrinterStatus();
    int updatePrinterState();
    String getPrinterSerialNo();
    String getPrinterVersion();
    String getPrinterModal();
    String getServiceVersion();
    void cutpaper(in Bundle extras);
}
