# NBG Parking — Sunmi Device App

A native Android app for Sunmi handheld terminals (built/tested against a
**Sunmi V2 Pro**, Android 7.1.2) that replaces manual entry/exit at the
parking gate:

- **Entry**: tap Bike or Car → a coupon prints instantly, with a barcode
  that encodes the vehicle type and entry time directly (no network
  needed).
- **Exit**: scan the coupon → pick Club / Special Club / Other → the bill
  is calculated on the device and a receipt prints immediately, with a
  FonePay QR for the exact amount.
- Everything is saved locally first and synced to Odoo automatically in
  the background — the gate keeps working even if the internet is down.

This talks to the `parking_management` Odoo module's device API
(`controllers/main.py`) — see the parent repo's README for that side.

---

## ⚠️ Status: strong starting point, not yet verified on real hardware

This code was written and carefully reviewed (every layout ID cross-checked
against the Kotlin that references it, every XML file validated, the fee
math verified against Odoo's own tested formula) but **has not been
compiled or run on an actual Sunmi device** — that requires physically
holding the device, which wasn't possible while writing this. Budget a
short session with an Android developer to build it, install it, and fix
the handful of things flagged below that can only be confirmed on real
hardware. None of them are architectural — they're all "which exact
constant/broadcast name does this specific firmware use" questions.

### The 2 things that need on-device verification

1. **Barcode symbology constant** (`print/SunmiPrinterHelper.kt`,
   `SYMBOLOGY_CODE128 = 8`). This is the commonly documented value for
   Sunmi's printer SDK, but if printed barcodes come out wrong, check
   Sunmi's "Printer Demo" sample app (from their developer site, search
   the model number) for the exact constant.
2. **Hardware scan broadcast** (`scan/HardwareScanReceiver.kt`). The class
   already listens for every action/extra-key combination commonly seen
   across Sunmi's product line, so there's a good chance it works
   unmodified. If a real scan doesn't trigger anything, run
   `adb logcat | grep ScanReceiver` while pressing the scan button/trigger
   to see the real intent, then add that action/extra to the two lists at
   the top of the file. **A camera-based fallback scanner is already
   built in** (`scan/CameraScannerActivity.kt`, ML Kit) as a safety net —
   the app is fully usable even if the hardware broadcast needs tuning.

---

## Requirements to build

- **Android Studio** (free, from developer.android.com) — Hedgehog or
  newer.
- The Sunmi device, plus a USB cable, for on-device testing.
- No Sunmi account or paid SDK needed — the printer AIDL interface
  (`app/src/main/aidl/woyou/aidlservice/jiuiv5/IWoyouService.aidl`) is
  Sunmi's public interface, included directly in this project.

## Build & install

1. Open this `sunmi_parking_app/` folder in Android Studio (`File > Open`).
2. Let it sync Gradle (first time downloads dependencies, a few minutes).
3. Plug the Sunmi device in via USB. On the device: **Settings > About
   device**, tap the build number a few times to unlock Developer Options,
   then enable **USB debugging** under the new Developer Options menu.
4. In Android Studio, select the device from the run-target dropdown and
   click **Run ▶**. The app installs and launches automatically.
5. To hand someone a finished copy without Android Studio: **Build >
   Generate Signed Bundle / APK > APK**, then copy the resulting `.apk`
   file onto the device (USB/flash drive) and tap it to install — that's
   the "installing an app" step described earlier, no computer needed at
   that point.

## First-run setup (on the device)

1. Launch the app — it opens the **Setup** screen automatically the first
   time.
2. **Odoo Server URL**: e.g. `https://parking.yourdomain.com` (must be an
   address this device can actually reach — see the note on hosting
   below).
3. **Device API Key**: from Odoo, go to **Parking > Configuration >
   Settings > Entry/Exit Device API**, click **Generate New Key**, copy it
   here.
4. **Gate / Device Name**: e.g. "Gate 1" — shows up in Odoo so you can
   tell gates apart in reports.
5. Tap **Test Connection & Save** — this also downloads and caches the
   current rates/categories so the device can calculate bills offline.
6. Tap **Done**.

Re-open Setup anytime from the gear icon on the home screen (e.g. to
change the server address, or after changing rates lets you manually
force a fresh sync — though that also happens automatically).

### About hosting Odoo

This app needs a real network path to your Odoo server. Running Odoo on a
laptop that's only sometimes on and only reachable on one WiFi network
works for testing, but for a real gate, host Odoo somewhere with a stable
address reachable from wherever the device has signal (WiFi or mobile
data) — a small cloud server is the standard way to do this.

---

## How the offline-first design works

- **Entry**: the coupon's barcode is `PK1|<coupon>|<type>|<entryEpochSeconds>`
  — completely self-contained. No server call is needed to print it.
- **Exit**: scanning that barcode decodes vehicle type + entry time
  directly, with no lookup. The category is picked on-screen, and the fee
  is computed on the device using the last-synced rates
  (`util/FeeCalculator.kt`, which mirrors Odoo's `_compute_charges` /
  `_round_billed_hours` / `_compute_tax` formula exactly — verified against
  Odoo's own test suite numbers). **Rounding rule**: free category minutes
  are deducted first; within the first hour, up to the vehicle type's Grace
  Period (e.g. 20 min) is free and the rest of the hour bills in full; from
  the second hour on, up to the 30-minute mark rounds down, past it rounds
  up (4h10m → 4h, 4h30m → 4h, 4h35m → 5h, and critically, an *exact* 6h00m
  bills 6 hours, never 7).
- Every finished transaction is saved to a local database
  (`data/TicketEntity.kt`, Room) the instant it happens, **before**
  printing is even attempted — a printer jam or a network outage can never
  lose a real transaction.
- A background worker (`sync/SyncWorker.kt`) uploads anything unsynced
  every 15 minutes automatically, and immediately after any entry/exit
  when the network is fine. Every server endpoint it calls is idempotent
  (safe to retry), so a flaky connection can never create duplicate
  tickets or double-charge a payment.
- The small sync indicator on the home screen ("✔ Synced" / "⏳ N
  pending") tells staff at a glance whether everything has reached Odoo.

## Manual fallback (damaged/lost coupon)

- **Enter Manually**: for a coupon whose barcode won't scan but is still
  readable — staff retype the coupon number, vehicle type, and entry time
  exactly as printed on the paper (the coupon prints these in plain text
  specifically for this purpose).
- **Lost Ticket**: for a coupon that's genuinely gone — staff just picks
  Bike or Car, and the vehicle type's configured flat lost-ticket fee is
  charged (same as the main Odoo web UI).

## Testing checklist once built

1. Setup screen connects and shows the right vehicle types/categories.
2. Entry: Bike and Car both generate a coupon, printed coupon shows a
   scannable barcode + readable text.
3. Exit: scanning that same coupon shows the right vehicle type, entry
   time, and lets you pick a category.
4. Bill amount matches manual math (e.g. Car, Other, exactly 6h00m parked
   → should be Rs 300 at the seeded rates, i.e. 6 hours × Rs 50 -- NOT 7
   hours; an exact hour must never round up. See the rounding rule below.)
5. Cash payment completes and prints a receipt.
6. FonePay payment shows a QR, accepts a reference, completes and prints.
7. Turn on Airplane Mode, repeat an entry + exit + payment — everything
   should still work, then turn Airplane Mode off and confirm the sync
   indicator drops to "✔ Synced" and the tickets appear in Odoo.
8. Enter Manually and Lost Ticket flows both work and sync correctly.
9. Confirm no duplicate tickets/payments appear in Odoo after step 7 (this
   is what the idempotent API design guarantees — worth double-checking
   once for peace of mind).

## Project layout

```
sunmi_parking_app/
├── app/src/main/
│   ├── aidl/woyou/aidlservice/jiuiv5/IWoyouService.aidl   Sunmi printer interface
│   ├── java/com/nbg/parkingapp/
│   │   ├── api/          Retrofit client for Odoo's device API
│   │   ├── data/          Room database (offline queue) + local settings
│   │   ├── print/         Sunmi printer wrapper
│   │   ├── scan/          Hardware scan listener + camera fallback
│   │   ├── sync/          Background sync worker
│   │   ├── ui/            MainActivity, SetupActivity, EntryActivity, ExitActivity
│   │   └── util/          Fee calculator, date formatting, QR/barcode helpers
│   ├── res/                Layouts, colours, launcher icon
│   └── AndroidManifest.xml
├── build.gradle.kts / settings.gradle.kts / gradle.properties
└── README.md (this file)
```
