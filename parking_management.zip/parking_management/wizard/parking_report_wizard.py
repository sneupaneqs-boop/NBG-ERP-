# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
import base64
import io
from collections import defaultdict
from datetime import datetime, time

from odoo import api, fields, models
from odoo.exceptions import UserError

try:
    import xlsxwriter
except ImportError:  # pragma: no cover - xlsxwriter ships with Odoo
    xlsxwriter = None

from ..models.parking_payment import PAYMENT_METHODS

METHOD_LABELS = dict(PAYMENT_METHODS)


class ParkingReportWizard(models.TransientModel):
    """Period report builder for parking payments / revenue.

    Produces a multi-sheet Excel workbook (Summary, Payments, By Method,
    By Operator, Daily Revenue) and a matching PDF collection report over a
    chosen date range.
    """

    _name = 'parking.report.wizard'
    _description = 'Parking Report'

    date_from = fields.Date(
        string='From', required=True,
        default=lambda self: fields.Date.context_today(self).replace(day=1),
    )
    date_to = fields.Date(
        string='To', required=True, default=fields.Date.context_today,
    )
    report_type = fields.Selection(
        selection=[
            ('collection', 'Collection Summary'),
            ('payments', 'Payment Detail'),
            ('method', 'By Payment Method'),
            ('operator', 'Operator Collection'),
            ('daily', 'Daily Revenue'),
        ],
        string='Report', default='collection', required=True,
    )
    file_data = fields.Binary(string='File', readonly=True)
    file_name = fields.Char(string='File Name', readonly=True)

    # ------------------------------------------------------------------
    # Data gathering
    # ------------------------------------------------------------------
    def _payment_domain(self):
        self.ensure_one()
        if self.date_from > self.date_to:
            raise UserError("'From' date must be before 'To' date.")
        start = datetime.combine(self.date_from, time.min)
        end = datetime.combine(self.date_to, time.max)
        return [
            ('state', '=', 'posted'),
            ('payment_date', '>=', fields.Datetime.to_string(start)),
            ('payment_date', '<=', fields.Datetime.to_string(end)),
            ('company_id', 'in', self.env.companies.ids),
        ]

    def get_report_data(self):
        """Return a dict of aggregated data used by both Excel and PDF."""
        self.ensure_one()
        payments = self.env['parking.payment'].search(
            self._payment_domain(), order='payment_date')
        currency = self.env.company.currency_id

        by_method = defaultdict(lambda: {'count': 0, 'total': 0.0})
        by_operator = defaultdict(lambda: {'count': 0, 'total': 0.0})
        by_day = defaultdict(lambda: {'count': 0, 'total': 0.0})
        rows = []
        total = 0.0
        for pay in payments:
            total += pay.amount
            by_method[pay.payment_method]['count'] += 1
            by_method[pay.payment_method]['total'] += pay.amount
            op = pay.operator_id.name or 'Unassigned'
            by_operator[op]['count'] += 1
            by_operator[op]['total'] += pay.amount
            day = fields.Datetime.context_timestamp(pay, pay.payment_date).date()
            by_day[day]['count'] += 1
            by_day[day]['total'] += pay.amount
            rows.append({
                'date': fields.Datetime.context_timestamp(pay, pay.payment_date),
                'name': pay.name,
                'ticket': pay.ticket_id.name,
                'vehicle': pay.ticket_id.vehicle_number,
                'method': METHOD_LABELS.get(pay.payment_method, pay.payment_method),
                'reference': pay.reference or '',
                'operator': op,
                'amount': pay.amount,
            })
        return {
            'currency': currency,
            'date_from': self.date_from,
            'date_to': self.date_to,
            'rows': rows,
            'total': total,
            'count': len(rows),
            'by_method': [
                {'label': METHOD_LABELS.get(k, k), **v}
                for k, v in sorted(by_method.items())
            ],
            'by_operator': [
                {'label': k, **v} for k, v in sorted(by_operator.items())
            ],
            'by_day': [
                {'label': k, **v} for k, v in sorted(by_day.items())
            ],
        }

    # ------------------------------------------------------------------
    # Excel
    # ------------------------------------------------------------------
    def action_export_xlsx(self):
        self.ensure_one()
        if xlsxwriter is None:
            raise UserError("The 'xlsxwriter' Python library is required.")
        data = self.get_report_data()
        output = io.BytesIO()
        book = xlsxwriter.Workbook(output, {'in_memory': True})

        title_f = book.add_format({'bold': True, 'font_size': 14})
        head_f = book.add_format({'bold': True, 'bg_color': '#D9E1F2', 'border': 1})
        cell_f = book.add_format({'border': 1})
        money_f = book.add_format({'border': 1, 'num_format': '#,##0.00'})
        total_f = book.add_format({'bold': True, 'border': 1, 'num_format': '#,##0.00', 'bg_color': '#FCE4D6'})
        date_f = book.add_format({'border': 1, 'num_format': 'yyyy-mm-dd hh:mm'})
        day_f = book.add_format({'border': 1, 'num_format': 'yyyy-mm-dd'})

        period = "%s to %s" % (data['date_from'], data['date_to'])

        # -- Summary sheet --
        ws = book.add_worksheet('Summary')
        ws.set_column(0, 0, 26)
        ws.set_column(1, 3, 16)
        ws.write(0, 0, 'Parking Collection Report', title_f)
        ws.write(1, 0, 'Period')
        ws.write(1, 1, period)
        ws.write(2, 0, 'Total Collected')
        ws.write(2, 1, data['total'], money_f)
        ws.write(3, 0, 'Payments')
        ws.write(3, 1, data['count'])
        ws.write(5, 0, 'By Payment Method', head_f)
        ws.write(5, 1, 'Count', head_f)
        ws.write(5, 2, 'Amount', head_f)
        r = 6
        for m in data['by_method']:
            ws.write(r, 0, m['label'], cell_f)
            ws.write(r, 1, m['count'], cell_f)
            ws.write(r, 2, m['total'], money_f)
            r += 1
        ws.write(r, 0, 'TOTAL', total_f)
        ws.write(r, 1, data['count'], total_f)
        ws.write(r, 2, data['total'], total_f)

        # -- Payments detail --
        ws = book.add_worksheet('Payments')
        headers = ['Date', 'Payment', 'Ticket', 'Vehicle', 'Method', 'Reference', 'Operator', 'Amount']
        widths = [18, 16, 16, 16, 12, 16, 18, 14]
        for c, (h, w) in enumerate(zip(headers, widths)):
            ws.write(0, c, h, head_f)
            ws.set_column(c, c, w)
        r = 1
        for row in data['rows']:
            ws.write_datetime(r, 0, row['date'].replace(tzinfo=None), date_f)
            ws.write(r, 1, row['name'], cell_f)
            ws.write(r, 2, row['ticket'] or '', cell_f)
            ws.write(r, 3, row['vehicle'] or '', cell_f)
            ws.write(r, 4, row['method'], cell_f)
            ws.write(r, 5, row['reference'], cell_f)
            ws.write(r, 6, row['operator'], cell_f)
            ws.write(r, 7, row['amount'], money_f)
            r += 1
        ws.write(r, 6, 'TOTAL', total_f)
        ws.write(r, 7, data['total'], total_f)

        # -- By Operator --
        ws = book.add_worksheet('By Operator')
        ws.set_column(0, 0, 24)
        ws.set_column(1, 2, 16)
        for c, h in enumerate(['Operator', 'Count', 'Amount']):
            ws.write(0, c, h, head_f)
        r = 1
        for o in data['by_operator']:
            ws.write(r, 0, o['label'], cell_f)
            ws.write(r, 1, o['count'], cell_f)
            ws.write(r, 2, o['total'], money_f)
            r += 1

        # -- Daily Revenue --
        ws = book.add_worksheet('Daily Revenue')
        ws.set_column(0, 0, 16)
        ws.set_column(1, 2, 16)
        for c, h in enumerate(['Date', 'Payments', 'Amount']):
            ws.write(0, c, h, head_f)
        r = 1
        for d in data['by_day']:
            ws.write_datetime(r, 0, datetime.combine(d['label'], time.min), day_f)
            ws.write(r, 1, d['count'], cell_f)
            ws.write(r, 2, d['total'], money_f)
            r += 1

        book.close()
        output.seek(0)
        self.file_data = base64.b64encode(output.read())
        self.file_name = 'parking_report_%s_%s.xlsx' % (self.date_from, self.date_to)
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/parking.report.wizard/%d/file_data/%s?download=true'
                   % (self.id, self.file_name),
            'target': 'self',
        }

    # ------------------------------------------------------------------
    # PDF
    # ------------------------------------------------------------------
    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref(
            'parking_management.report_parking_collection').report_action(self)
