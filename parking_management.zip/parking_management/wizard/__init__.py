# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from . import parking_payment_wizard
from . import parking_report_wizard
