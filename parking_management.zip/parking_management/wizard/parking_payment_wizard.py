# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models
from odoo.exceptions import UserError

from ..models.parking_payment import PAYMENT_METHODS


class ParkingPaymentWizard(models.TransientModel):
    """Collect a payment for a parking ticket at exit.

    Presents the amount due, lets the cashier choose Cash or FonePay (and
    other configured methods), shows the static FonePay QR when relevant and
    records the payment through :meth:`parking.ticket._register_payment`.
    """

    _name = 'parking.payment.wizard'
    _description = 'Register Parking Payment'

    ticket_id = fields.Many2one(
        'parking.ticket', string='Ticket', required=True, readonly=True,
    )
    vehicle_number = fields.Char(related='ticket_id.vehicle_number', readonly=True)
    duration_display = fields.Char(related='ticket_id.duration_display', readonly=True)
    currency_id = fields.Many2one(related='ticket_id.currency_id', readonly=True)
    amount_total = fields.Monetary(
        related='ticket_id.amount_total', string='Parking Charge', readonly=True,
    )
    tax_amount = fields.Monetary(related='ticket_id.tax_amount', string='VAT', readonly=True)
    amount_due = fields.Monetary(
        related='ticket_id.amount_residual', string='Amount Due', readonly=True,
    )
    amount = fields.Monetary(
        string='Amount Received', currency_field='currency_id', required=True,
    )
    payment_method = fields.Selection(
        selection=PAYMENT_METHODS, string='Payment Method', default='cash', required=True,
    )
    reference = fields.Char(string='Transaction Reference')
    fonepay_qr = fields.Binary(
        string='FonePay QR', compute='_compute_fonepay_qr',
        help="Static merchant FonePay QR shown to the customer for online payment.",
    )
    change_due = fields.Monetary(
        string='Change', currency_field='currency_id', compute='_compute_change',
    )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        ticket_id = res.get('ticket_id') or self.env.context.get('default_ticket_id')
        if ticket_id and 'amount' in fields_list and not res.get('amount'):
            ticket = self.env['parking.ticket'].browse(ticket_id)
            res['amount'] = ticket.amount_residual
        return res

    @api.depends('payment_method', 'amount', 'amount_due')
    def _compute_fonepay_qr(self):
        connector = self.env['parking.fonepay.connector']
        for wizard in self:
            if wizard.payment_method == 'fonepay':
                amount = wizard.amount or wizard.amount_due
                wizard.fonepay_qr = connector.generate_qr_image(
                    amount, wizard.ticket_id.name)
            else:
                wizard.fonepay_qr = False

    @api.depends('amount', 'amount_due', 'payment_method')
    def _compute_change(self):
        for wizard in self:
            if wizard.payment_method == 'cash':
                wizard.change_due = max(0.0, wizard.amount - wizard.amount_due)
            else:
                wizard.change_due = 0.0

    def action_confirm_payment(self):
        self.ensure_one()
        if self.amount <= 0:
            raise UserError("Please enter a payment amount greater than zero.")
        if self.payment_method != 'cash' and not self.reference:
            raise UserError(
                "Please enter the transaction reference for a "
                f"{dict(PAYMENT_METHODS).get(self.payment_method)} payment.")
        # For non-cash methods, never over-post beyond what is due.
        amount = self.amount
        if self.payment_method != 'cash':
            amount = min(amount, self.amount_due)
        else:
            amount = min(amount, self.amount_due)
        self.ticket_id._register_payment(amount, self.payment_method, self.reference)
        return {'type': 'ir.actions.act_window_close'}
