# Parking Management (Odoo 18 Community)

A production-ready parking management ERP for Odoo 18 Community. Built around a
real operation: an **entry machine dispenses a coupon and records the entry
time**, and Odoo is the **exit / cashier tool** that automatically calculates
the fee and produces a **FonePay QR for the exact amount**.

Verified on a live Odoo 18 instance — **26 unit tests pass** (`0 failed,
0 errors`), thermal receipts and reports render to PDF/Excel, and the OWL
dashboard runs in the browser.

---

## Table of contents

1. [Features](#features)
2. [Requirements](#requirements)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [How to access](#how-to-access)
6. [How to use (daily workflow)](#how-to-use-daily-workflow)
7. [How to connect](#how-to-connect)
8. [Dashboard & reports](#dashboard--reports)
9. [Security roles](#security-roles)
10. [Module structure](#module-structure)
11. [Testing](#testing)
12. [Future improvements](#future-improvements)

---

## Features

- **Exit-first billing**: enter coupon number + entry time + type/category, set
  exit time → the fee is calculated automatically.
- **Configurable rate engine** — flat hourly charge per vehicle type
  (Bike Rs 30/hr, Car Rs 50/hr…), **free minutes per parking category**
  (Club 45 min, Special Club 90 min, Other 0 min), **round up per started
  hour**, **VAT-inclusive** tax, optional daily cap, lost-ticket charge,
  monthly-pass = free. **No hard-coded values.**
- **QR & barcode** on every coupon; **dynamic FonePay QR** encoding the amount
  due (via a pluggable `FonePayConnector`).
- **Thermal receipts** (58 mm & 80 mm): entry coupon and exit receipt.
- **Multi-method payments** (Cash, FonePay, Card, eSewa, Khalti, Bank) with a
  one-screen payment wizard.
- **Accounting integration**: each payment posts a balanced journal entry
  (Dr Cash/Bank, Cr Parking Income, + VAT Output if configured).
- **OWL dashboard**: revenue/vehicle KPIs and charts.
- **Reports**: multi-sheet **Excel** + **PDF** collection reports over any date
  range.
- **Monthly passes**, **parking slots** with a colour board, **role-based
  security**, and architecture ready for **TIGG** accounting and **barrier-gate**
  integration.

---

## Requirements

| Component  | Version            |
|------------|--------------------|
| Odoo       | 18.0 Community     |
| Python     | 3.11 / 3.12        |
| PostgreSQL | 12+                |

Depends on the standard `base`, `mail`, `account` and `web` modules.

**System dependencies for QR / barcode / receipts**

- `wkhtmltopdf` (0.12.6) for PDF receipts: `apt-get install wkhtmltopdf`.
- A working **reportlab PNG backend** for QR/barcode rasterisation. On slim
  installs run once: `pip install rlPyCairo pycairo` (needs `libcairo2` /
  `libcairo2-dev`). `xlsxwriter` (bundled with Odoo) powers the Excel export.
  Standard Odoo deployments already satisfy all of these.

---

## Installation

1. Copy the `parking_management` folder into your Odoo `addons` path.
2. Restart Odoo, enable **Developer Mode**, open **Apps → Update Apps List**.
3. Search **Parking Management** → **Install**.

Command line:

```bash
odoo-bin -c odoo.conf -d your_db -i parking_management
```

---

## Configuration

Open **Parking → Configuration**:

1. **Parking Categories** — free-minute allowances. Seeded with
   *Club parking (45)*, *Special Club Parking (90)*, *Other (0, default)*.
   Add more venues here anytime.
2. **Vehicle Types** — Bike / Car / Bus (add your own).
3. **Rate Plans** — the **Hourly Charge** per type (Bike 30, Car 50…), plus
   optional daily cap, lost-ticket and monthly charges.
4. **Settings** (Parking → Configuration → Settings):
   - **Default Tax Rate** (13% VAT, treated as inclusive) and grace period.
   - **FonePay Dynamic QR**: enable it and enter your merchant code/endpoint
     (a local placeholder QR is produced until the live API is wired in).
   - **Accounting**: choose the **Parking Journal**, **Parking Income Account**
     and optional **VAT Output Account**.
5. **Users** — assign each user a parking role (see [Security roles](#security-roles)).

---

## How to access

- **App menu**: after install, a **Parking** app appears in the top apps menu.
- **Direct URL**: `https://<your-odoo>/odoo/action-parking_management.action_parking_dashboard`
  opens the dashboard; the exit screen is **Parking → Operations → Exit /
  Calculate Bill**.
- Menu map:
  - **Dashboard** – KPIs & charts
  - **Operations** – Exit / Calculate Bill · Vehicle Entry · Tickets · Parking
    Board · Monthly Passes
  - **Payments** – all payments
  - **Vehicles** – registered vehicles
  - **Reporting** – Excel/PDF reports
  - **Configuration** – categories, rates, slots, settings

---

## How to use (daily workflow)

**Exit / cashier flow (primary — the machine handled entry):**

1. Go to **Parking → Operations → Exit / Calculate Bill**.
2. Enter the **Coupon Number**, the **Entry Time** printed on the coupon, the
   **Vehicle Type** and **Parking Category** (Club / Special Club / Other).
   *(Tip: a USB barcode scanner can fill the coupon field in one scan.)*
3. Set the **Exit Time** (defaults to now) and click **Calculate & Charge** —
   the fee, VAT and total are computed automatically.
4. The **payment screen** opens showing a **FonePay QR for the exact amount**.
   The customer scans and pays, or pays cash; enter the reference for FonePay.
5. Click **Register Payment** → the ticket is marked **Paid**, the journal entry
   is posted, and you can **Print Receipt** (80/58 mm).
6. **Lost ticket?** Use the **Lost Ticket** button to bill the fixed
   lost-ticket charge.

**Entry-in-Odoo flow (optional / hybrid):** *Vehicle Entry* creates the coupon
in Odoo (auto slot assignment, QR + barcode), then *Register Exit* → payment.

---

## How to connect

### Getting entry data from your machine

Odoo can receive machine data four ways (pick per your hardware):

| Option | How | When |
|--------|-----|------|
| **Scan the coupon** | USB scanner reads the coupon barcode into the coupon field at exit. | Coupon has a barcode |
| **HTTP endpoint** | A `/parking/entry` controller the machine/middleware POSTs to at entry (the `controllers/` package is scaffolded for this). | Machine can call a URL |
| **File import** | Scheduled job imports a CSV the machine exports. | Machine writes files |
| **DB / serial bridge** | A local agent reads the machine DB or RS-232/TCP gate. | Barrier-gate hardware |

Tell us what the coupon barcode encodes (number only, or number + entry time)
and whether the machine can call a URL, and the matching connector is wired in.

### FonePay

All FonePay logic goes through `parking.fonepay.connector`
(`models/fonepay_connector.py`). Today it renders a local QR encoding the
amount; going live means implementing `request_dynamic_qr()` /
`check_payment_status()` against either the **FonePay Dynamic-QR API** or a
**NepalQR/EMVCo** payload — nothing else in the module changes.

### TIGG accounting (future)

The architecture reserves a `TIGGConnector`-style boundary
(`send_payment()` / `sync_transaction()` / `retry_failed()`) so parking
payments can be pushed to TIGG without touching business logic.

---

## Dashboard & reports

- **Dashboard**: Today/Month revenue, Today's Vehicles, Currently Parked,
  Avg. Parking Time; daily-revenue bar, vehicles-by-type doughnut,
  revenue-by-method pie, operator collection.
- **Reports** (Parking → Reporting → Reports): pick a date range, then
  **Export Excel** (Summary / Payments / By Operator / Daily Revenue sheets) or
  **Print PDF** (collection summary). The Payments list also supports Odoo's
  built-in ⚙ **Export**.

---

## Security roles

| Role            | Capabilities                                              |
|-----------------|-----------------------------------------------------------|
| Security Guard  | Read-only tickets & slots                                 |
| Gate Operator   | Register entry/exit, manage slots & vehicles              |
| Cashier         | Collect payments, sell passes, run reports                |
| Parking Manager | Configure rates/categories/slots, review reports          |
| Administrator   | Full control incl. settings                               |

Roles are hierarchical — each higher role inherits the lower ones.

---

## Module structure

```
parking_management/
├── models/         vehicle type, category, rate, vehicle, slot, ticket,
│                   payment, monthly pass, fonepay_connector, account.move,
│                   dashboard, res.company, res.config.settings
├── wizard/         payment wizard, report wizard
├── controllers/    (machine/QR-scan endpoints — see "How to connect")
├── report/         thermal receipts (coupon + exit) and collection report
├── security/       5 roles, record rules, access rights
├── data/           sequences, categories, default types & rates
├── views/          list/form/kanban/search, dashboard action, menus
├── static/src/     OWL dashboard (JS, XML, SCSS)
├── tests/          26 unit tests (rate engine, workflow, accounting, reports)
└── README.md
```

---

## Testing

```bash
odoo-bin -d test_db -i parking_management \
    --test-enable --test-tags /parking_management --stop-after-init
```

Covers fee calculation (free minutes, round-up, VAT-inclusive, lost ticket,
daily cap, monthly pass), ticket/code creation, slot allocation, the
entry→exit→pay workflow, payment accounting (balanced posted entry, cancel
reversal, VAT split) and the report/dashboard data.

---

## Future improvements

- Live FonePay Dynamic-QR API + automatic payment reconciliation.
- Barrier-gate hardware integration (ANPR camera, RS-232/TCP controller).
- TIGG accounting sync.
- Customer self-service portal and SMS/receipt delivery.

## License

LGPL-3
