# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from . import test_rate_engine
from . import test_workflow
from . import test_accounting
from . import test_reports
