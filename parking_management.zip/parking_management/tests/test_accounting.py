# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from datetime import datetime, timedelta

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestAccounting(TransactionCase):
    """Payment posting creates a balanced, posted journal entry."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Ticket = cls.env['parking.ticket']
        cls.car = cls.env.ref('parking_management.vehicle_type_car')
        cls.cat_other = cls.env.ref('parking_management.category_other')

        # Self-contained accounting setup (works even without a CoA).
        Account = cls.env['account.account']
        cls.acc_bank = Account.create({
            'name': 'Parking Cash', 'code': 'PKCASH',
            'account_type': 'asset_cash'})
        cls.acc_income = Account.create({
            'name': 'Parking Income', 'code': 'PKINC',
            'account_type': 'income'})
        cls.journal = cls.env['account.journal'].create({
            'name': 'Parking', 'type': 'cash', 'code': 'PKJ',
            'default_account_id': cls.acc_bank.id})
        icp = cls.env['ir.config_parameter'].sudo()
        icp.set_param('parking_management.journal_id', cls.journal.id)
        icp.set_param('parking_management.income_account_id', cls.acc_income.id)

    def _paid_ticket(self, minutes=120, method='cash'):
        entry = datetime(2026, 1, 1, 8, 0, 0)
        ticket = self.Ticket.create({
            'vehicle_number': 'ACC', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id, 'entry_time': entry,
            'exit_time': entry + timedelta(minutes=minutes)})
        ticket.action_register_exit()
        ticket._register_payment(ticket.amount_residual, method)
        return ticket

    def test_payment_creates_posted_balanced_move(self):
        ticket = self._paid_ticket(120)  # 2h car -> 100
        payment = ticket.payment_ids[:1]
        self.assertEqual(payment.state, 'posted')
        move = payment.move_id
        self.assertTrue(move)
        self.assertEqual(move.state, 'posted')
        debit = sum(move.line_ids.mapped('debit'))
        credit = sum(move.line_ids.mapped('credit'))
        self.assertAlmostEqual(debit, credit, 2)
        self.assertAlmostEqual(debit, 100.0, 2)
        self.assertEqual(move.parking_payment_id, payment)

    def test_move_debits_bank_credits_income(self):
        ticket = self._paid_ticket(60)  # 50
        move = ticket.payment_ids[:1].move_id
        bank_line = move.line_ids.filtered(lambda l: l.account_id == self.acc_bank)
        income_line = move.line_ids.filtered(lambda l: l.account_id == self.acc_income)
        self.assertAlmostEqual(bank_line.debit, 50.0, 2)
        self.assertAlmostEqual(income_line.credit, 50.0, 2)

    def test_cancel_reverses_move(self):
        ticket = self._paid_ticket(60)
        payment = ticket.payment_ids[:1]
        move = payment.move_id
        payment.action_cancel()
        self.assertEqual(payment.state, 'cancelled')
        self.assertFalse(payment.move_id)
        self.assertFalse(move.exists())

    def test_vat_split_when_tax_account_set(self):
        self.env['ir.config_parameter'].sudo().set_param(
            'parking_management.tax_account_id', self.acc_income.id and
            self.env['account.account'].create({
                'name': 'VAT Output', 'code': 'PKVAT',
                'account_type': 'liability_current'}).id)
        ticket = self._paid_ticket(60)  # 50 incl 13% VAT
        move = ticket.payment_ids[:1].move_id
        # three lines: bank debit + income credit + vat credit
        self.assertEqual(len(move.line_ids), 3)
        self.assertAlmostEqual(
            sum(move.line_ids.mapped('debit')),
            sum(move.line_ids.mapped('credit')), 2)
