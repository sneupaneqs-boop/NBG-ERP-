# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from datetime import datetime, timedelta

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestRateEngine(TransactionCase):
    """Fee-calculation rules: free minutes, round-up hours, VAT-inclusive."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Ticket = cls.env['parking.ticket']
        cls.car = cls.env.ref('parking_management.vehicle_type_car')
        cls.bike = cls.env.ref('parking_management.vehicle_type_bike')
        cls.cat_other = cls.env.ref('parking_management.category_other')
        cls.cat_club = cls.env.ref('parking_management.category_club')
        cls.cat_special = cls.env.ref('parking_management.category_special_club')

    def _ticket(self, vtype, category, minutes):
        entry = datetime(2026, 1, 1, 8, 0, 0)
        return self.Ticket.create({
            'vehicle_number': 'TEST',
            'vehicle_type_id': vtype.id,
            'category_id': category.id,
            'entry_time': entry,
            'exit_time': entry + timedelta(minutes=minutes),
        })

    def test_seed_free_minutes(self):
        self.assertEqual(self.cat_club.free_minutes, 45)
        self.assertEqual(self.cat_special.free_minutes, 90)
        self.assertEqual(self.cat_other.free_minutes, 0)

    def test_car_other_roundup(self):
        # 1h10m car / no free -> 2 started hours -> 2 * 50
        ticket = self._ticket(self.car, self.cat_other, 70)
        self.assertEqual(ticket.billed_hours, 2)
        self.assertAlmostEqual(ticket.amount_total, 100.0, 2)

    def test_bike_other_roundup(self):
        # 1h05m bike -> 2h -> 2 * 30
        ticket = self._ticket(self.bike, self.cat_other, 65)
        self.assertAlmostEqual(ticket.amount_total, 60.0, 2)

    def test_special_club_90_free(self):
        # 2h00m car, 90 free -> 30m chargeable -> 1h -> 50
        ticket = self._ticket(self.car, self.cat_special, 120)
        self.assertEqual(ticket.billed_hours, 1)
        self.assertAlmostEqual(ticket.amount_total, 50.0, 2)

    def test_club_within_free_is_zero(self):
        ticket = self._ticket(self.bike, self.cat_club, 40)  # < 45 free
        self.assertAlmostEqual(ticket.amount_total, 0.0, 2)

    def test_club_excess_only(self):
        # 1h50m bike, 45 free -> 65m chargeable -> 2h -> 60
        ticket = self._ticket(self.bike, self.cat_club, 110)
        self.assertAlmostEqual(ticket.amount_total, 60.0, 2)

    def test_tax_is_inclusive(self):
        ticket = self._ticket(self.car, self.cat_other, 60)  # 1h -> 50
        self.assertAlmostEqual(ticket.grand_total, 50.0, 2)
        self.assertGreater(ticket.tax_rate, 0.0)
        expected_vat = round(50.0 - 50.0 / (1 + ticket.tax_rate / 100.0), 2)
        self.assertAlmostEqual(ticket.tax_amount, expected_vat, 2)
        self.assertAlmostEqual(
            ticket.amount_untaxed + ticket.tax_amount, ticket.grand_total, 2)

    def test_discount_reduces_total(self):
        ticket = self._ticket(self.car, self.cat_other, 60)  # 50
        ticket.discount = 10.0
        self.assertAlmostEqual(ticket.grand_total, 40.0, 2)

    def test_lost_ticket_charge(self):
        ticket = self._ticket(self.car, self.cat_other, 30)
        ticket.action_lost_ticket()
        self.assertTrue(ticket.is_lost_ticket)
        self.assertAlmostEqual(ticket.amount_total, 500.0, 2)  # car lost fee

    def test_daily_cap(self):
        self.car.rate_ids[:1].max_daily_charge = 300.0
        # 10h car would be 500, capped to 300
        ticket = self._ticket(self.car, self.cat_other, 600)
        self.assertAlmostEqual(ticket.amount_total, 300.0, 2)

    def test_monthly_pass_is_free(self):
        today = self.env.cr.now() if hasattr(self.env.cr, 'now') else None
        partner = self.env['res.partner'].create({'name': 'Pass Holder'})
        vehicle = self.env['parking.vehicle'].create({
            'name': 'PASS-1', 'vehicle_type_id': self.car.id,
            'partner_id': partner.id})
        from odoo import fields
        d_today = fields.Date.context_today(self.env.user)
        self.env['parking.monthly.pass'].create({
            'partner_id': partner.id, 'vehicle_id': vehicle.id,
            'valid_from': d_today - timedelta(days=5),
            'valid_to': d_today + timedelta(days=25),
            'state': 'active',
        })
        entry = datetime(2026, 1, 1, 8, 0, 0)
        ticket = self.Ticket.create({
            'vehicle_id': vehicle.id, 'vehicle_number': 'PASS-1',
            'vehicle_type_id': self.car.id, 'category_id': self.cat_other.id,
            'entry_time': entry, 'exit_time': entry + timedelta(hours=5)})
        self.assertTrue(ticket.is_pass_covered)
        self.assertAlmostEqual(ticket.amount_total, 0.0, 2)
