# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from datetime import datetime, timedelta

from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestWorkflow(TransactionCase):
    """Ticket creation, code generation, slot allocation and the exit flow."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Ticket = cls.env['parking.ticket']
        cls.car = cls.env.ref('parking_management.vehicle_type_car')
        cls.cat_other = cls.env.ref('parking_management.category_other')
        cls.env['ir.config_parameter'].sudo().set_param(
            'parking_management.auto_assign_slot', 'True')

    def _new_slot(self):
        return self.env['parking.slot'].create({
            'name': 'TST-%s' % self.env['parking.slot'].search_count([]),
            'state': 'available'})

    def test_ticket_number_sequence(self):
        ticket = self.Ticket.create({
            'vehicle_number': 'SEQ-1', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id})
        self.assertTrue(ticket.name.startswith('PK/'))
        self.assertNotEqual(ticket.name, 'New')

    def test_codes_generated(self):
        ticket = self.Ticket.create({
            'coupon_number': 'CPN-1', 'vehicle_number': 'CODE-1',
            'vehicle_type_id': self.car.id, 'category_id': self.cat_other.id})
        self.assertEqual(ticket.barcode, 'CPN-1')
        self.assertTrue(ticket.qr_code)
        self.assertTrue(ticket.barcode_image)

    def test_fonepay_qr_follows_amount(self):
        entry = datetime(2026, 1, 1, 8, 0, 0)
        ticket = self.Ticket.create({
            'vehicle_number': 'FP-1', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id, 'entry_time': entry,
            'exit_time': entry + timedelta(hours=1)})
        self.assertTrue(ticket.fonepay_qr_image)
        payload = self.env['parking.fonepay.connector'].build_payload(
            ticket.grand_total, ticket.name)
        self.assertIn('AMOUNT:50.00', payload)

    def test_confirm_entry_assigns_and_occupies_slot(self):
        self._new_slot()
        ticket = self.Ticket.create({
            'vehicle_number': 'ENT-1', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id})
        ticket.action_confirm_entry()
        self.assertEqual(ticket.state, 'active')
        self.assertTrue(ticket.slot_id)
        self.assertEqual(ticket.slot_id.state, 'occupied')
        self.assertEqual(ticket.slot_id.current_ticket_id, ticket)

    def test_exit_first_from_draft(self):
        entry = datetime(2026, 1, 1, 8, 0, 0)
        ticket = self.Ticket.create({
            'vehicle_number': 'EX-1', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id, 'entry_time': entry,
            'exit_time': entry + timedelta(hours=2)})
        ticket.action_register_exit()  # straight from draft
        self.assertEqual(ticket.state, 'to_pay')
        self.assertAlmostEqual(ticket.amount_total, 100.0, 2)

    def test_full_payment_paid_and_frees_slot(self):
        slot = self._new_slot()
        ticket = self.Ticket.create({
            'vehicle_number': 'PAY-1', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id, 'slot_id': slot.id})
        ticket.action_confirm_entry()
        self.assertEqual(slot.state, 'occupied')
        ticket.exit_time = ticket.entry_time + timedelta(hours=1)
        ticket.state = 'to_pay'
        ticket._register_payment(ticket.amount_residual, 'cash')
        self.assertTrue(ticket.is_paid)
        self.assertEqual(ticket.state, 'paid')
        self.assertEqual(slot.state, 'available')
        self.assertFalse(slot.current_ticket_id)

    def test_exit_after_entry_constraint(self):
        from psycopg2 import IntegrityError
        from odoo.tools import mute_logger
        entry = datetime(2026, 1, 1, 8, 0, 0)
        with self.assertRaises(IntegrityError), mute_logger('odoo.sql_db'):
            with self.cr.savepoint():
                self.Ticket.create({
                    'vehicle_number': 'BAD', 'vehicle_type_id': self.car.id,
                    'category_id': self.cat_other.id, 'entry_time': entry,
                    'exit_time': entry - timedelta(hours=1)})
