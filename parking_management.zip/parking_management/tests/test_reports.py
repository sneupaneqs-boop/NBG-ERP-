# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
import base64
from datetime import datetime, timedelta

from odoo import fields
from odoo.tests.common import TransactionCase, tagged


@tagged('post_install', '-at_install')
class TestReports(TransactionCase):
    """Report wizard (Excel/data) and dashboard data provider."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Ticket = cls.env['parking.ticket']
        cls.car = cls.env.ref('parking_management.vehicle_type_car')
        cls.cat_other = cls.env.ref('parking_management.category_other')

    def _seed_payment(self, method='cash'):
        entry = fields.Datetime.now() - timedelta(hours=2)
        ticket = self.Ticket.create({
            'vehicle_number': 'RPT', 'vehicle_type_id': self.car.id,
            'category_id': self.cat_other.id, 'entry_time': entry})
        ticket.action_register_exit()
        if ticket.amount_residual > 0:
            ticket._register_payment(ticket.amount_residual, method)
        return ticket

    def test_report_data(self):
        self._seed_payment('cash')
        self._seed_payment('fonepay')
        today = fields.Date.context_today(self.env.user)
        wizard = self.env['parking.report.wizard'].create({
            'date_from': today, 'date_to': today})
        data = wizard.get_report_data()
        self.assertGreaterEqual(data['count'], 2)
        self.assertGreater(data['total'], 0.0)
        self.assertTrue(data['by_method'])
        self.assertTrue(data['by_operator'])

    def test_xlsx_export(self):
        self._seed_payment('cash')
        today = fields.Date.context_today(self.env.user)
        wizard = self.env['parking.report.wizard'].create({
            'date_from': today, 'date_to': today})
        action = wizard.action_export_xlsx()
        self.assertEqual(action['type'], 'ir.actions.act_url')
        self.assertTrue(wizard.file_data)
        raw = base64.b64decode(wizard.file_data)
        self.assertEqual(raw[:2], b'PK')  # xlsx is a zip container

    def test_report_date_validation(self):
        from odoo.exceptions import UserError
        today = fields.Date.context_today(self.env.user)
        wizard = self.env['parking.report.wizard'].create({
            'date_from': today, 'date_to': today - timedelta(days=1)})
        with self.assertRaises(UserError):
            wizard.get_report_data()

    def test_dashboard_data_shape(self):
        self._seed_payment('cash')
        data = self.env['parking.dashboard'].get_dashboard_data()
        self.assertIn('kpi', data)
        self.assertIn('today_revenue', data['kpi'])
        self.assertIn('currently_parked', data['kpi'])
        self.assertNotIn('available_slots', data['kpi'])  # removed by request
        self.assertEqual(len(data['daily']['values']), 7)
        self.assertIn('by_type', data)
        self.assertIn('by_method', data)
