# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
"""Parking Management module top-level package.

Sub-packages are imported here so Odoo can discover the models, wizards
and controllers that make up the module.  Additional packages (``wizard``,
``controllers``, ``report``) are wired in as later phases add them.
"""
from . import models
from . import wizard
