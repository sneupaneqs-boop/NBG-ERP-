# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models

# Kanban colour indices (match Odoo's colour palette) used by the visual board.
SLOT_STATE_COLORS = {
    'available': 10,    # green
    'occupied': 1,      # red
    'reserved': 3,      # yellow
    'maintenance': 8,   # grey/blue
}


class ParkingSlot(models.Model):
    """A physical parking space.

    The slot's :attr:`state` drives the colour-coded dashboard:
    green = available, red = occupied, yellow = reserved, grey = maintenance.
    """

    _name = 'parking.slot'
    _description = 'Parking Slot'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'floor, section, name'

    name = fields.Char(string='Slot Number', required=True, index=True)
    floor = fields.Char(string='Floor', default='Ground')
    section = fields.Char(string='Section')
    sequence = fields.Integer(string='Sequence', default=10)
    active = fields.Boolean(string='Active', default=True)

    state = fields.Selection(
        selection=[
            ('available', 'Available'),
            ('occupied', 'Occupied'),
            ('reserved', 'Reserved'),
            ('maintenance', 'Maintenance'),
        ],
        string='Status',
        default='available',
        required=True,
        index=True,
        tracking=True,
    )
    color = fields.Integer(
        string='Colour', compute='_compute_color', store=True,
    )

    vehicle_type_id = fields.Many2one(
        comodel_name='parking.vehicle.type',
        string='Allowed Vehicle Type',
        help="Restrict this slot to a vehicle type. Empty means any vehicle.",
    )
    current_ticket_id = fields.Many2one(
        comodel_name='parking.ticket',
        string='Current Ticket',
        readonly=True,
        copy=False,
    )
    current_vehicle_id = fields.Many2one(
        comodel_name='parking.vehicle',
        string='Current Vehicle',
        related='current_ticket_id.vehicle_id',
        store=True,
        readonly=True,
    )
    current_vehicle_number = fields.Char(
        string='Vehicle Number',
        related='current_ticket_id.vehicle_number',
        readonly=True,
    )

    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('slot_uniq', 'unique(name, company_id)',
         'A slot with this number already exists for this company.'),
    ]

    @api.depends('state')
    def _compute_color(self):
        for slot in self:
            slot.color = SLOT_STATE_COLORS.get(slot.state, 0)

    @api.depends('name', 'floor', 'section')
    def _compute_display_name(self):
        for slot in self:
            parts = [p for p in (slot.floor, slot.section, slot.name) if p]
            slot.display_name = ' / '.join(parts) if parts else slot.name

    # --- Actions used by the dashboard (logic completed in Phase 2) --------
    def action_set_available(self):
        return self.write({'state': 'available'})

    def action_set_maintenance(self):
        return self.write({'state': 'maintenance'})

    def action_set_reserved(self):
        return self.write({'state': 'reserved'})
