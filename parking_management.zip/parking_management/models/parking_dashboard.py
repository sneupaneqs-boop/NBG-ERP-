# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from datetime import datetime, time, timedelta

from odoo import api, fields, models


class ParkingDashboard(models.AbstractModel):
    """Server-side data provider for the OWL parking dashboard."""

    _name = 'parking.dashboard'
    _description = 'Parking Dashboard Data'

    @api.model
    def _sum_payments(self, start, end):
        self.env.cr.execute(
            """
            SELECT COALESCE(SUM(amount), 0.0)
              FROM parking_payment
             WHERE state = 'posted'
               AND payment_date >= %s AND payment_date <= %s
               AND company_id = ANY(%s)
            """,
            (start, end, self.env.companies.ids),
        )
        return self.env.cr.fetchone()[0] or 0.0

    @api.model
    def get_dashboard_data(self):
        """Return KPIs and chart series for the dashboard."""
        Ticket = self.env['parking.ticket']
        Payment = self.env['parking.payment']
        company_ids = self.env.companies.ids
        today = fields.Date.context_today(self)
        day_start = datetime.combine(today, time.min)
        day_end = datetime.combine(today, time.max)
        month_start = datetime.combine(today.replace(day=1), time.min)

        # --- KPIs ---
        today_revenue = self._sum_payments(day_start, day_end)
        month_revenue = self._sum_payments(month_start, day_end)
        today_vehicles = Ticket.search_count([
            ('entry_time', '>=', day_start), ('entry_time', '<=', day_end),
            ('company_id', 'in', company_ids)])
        currently_parked = Ticket.search_count([
            ('state', '=', 'active'), ('company_id', 'in', company_ids)])

        avg_group = Ticket._read_group(
            [('exit_time', '>=', day_start), ('exit_time', '<=', day_end),
             ('company_id', 'in', company_ids)],
            aggregates=['duration:avg'])
        avg_duration = (avg_group[0][0] or 0.0) if avg_group else 0.0

        # --- Daily revenue, last 7 days ---
        daily_labels, daily_values = [], []
        for i in range(6, -1, -1):
            day = today - timedelta(days=i)
            s = datetime.combine(day, time.min)
            e = datetime.combine(day, time.max)
            daily_labels.append(day.strftime('%a %d'))
            daily_values.append(round(self._sum_payments(s, e), 2))

        # --- Tickets by vehicle type (this month) ---
        type_group = Ticket._read_group(
            [('entry_time', '>=', month_start), ('company_id', 'in', company_ids)],
            groupby=['vehicle_type_id'], aggregates=['__count'])
        by_type = {
            'labels': [(t.name if t else 'Unknown') for t, _ in type_group],
            'values': [c for _, c in type_group],
        }

        # --- Payments by method (this month) ---
        method_group = Payment._read_group(
            [('state', '=', 'posted'), ('payment_date', '>=', month_start),
             ('company_id', 'in', company_ids)],
            groupby=['payment_method'], aggregates=['amount:sum'])
        method_labels = dict(Payment._fields['payment_method'].selection)
        by_method = {
            'labels': [method_labels.get(m, m or 'Other') for m, _ in method_group],
            'values': [round(a or 0.0, 2) for _, a in method_group],
        }

        # --- Operator collection (today) ---
        op_group = Payment._read_group(
            [('state', '=', 'posted'), ('payment_date', '>=', day_start),
             ('payment_date', '<=', day_end), ('company_id', 'in', company_ids)],
            groupby=['operator_id'], aggregates=['amount:sum'])
        operators = [
            {'label': (op.name if op else 'Unassigned'), 'total': round(a or 0.0, 2)}
            for op, a in op_group
        ]

        return {
            'currency_symbol': self.env.company.currency_id.symbol or '',
            'kpi': {
                'today_revenue': round(today_revenue, 2),
                'month_revenue': round(month_revenue, 2),
                'today_vehicles': today_vehicles,
                'currently_parked': currently_parked,
                'avg_duration': round(avg_duration, 2),
            },
            'daily': {'labels': daily_labels, 'values': daily_values},
            'by_type': by_type,
            'by_method': by_method,
            'operators': operators,
        }
