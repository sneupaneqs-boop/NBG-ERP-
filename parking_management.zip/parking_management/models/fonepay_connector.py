# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
import base64
import logging

from odoo import api, models

_logger = logging.getLogger(__name__)

TRUE_STRINGS = ('True', 'true', '1', 'yes', 'on')


class ParkingFonepayConnector(models.AbstractModel):
    """Integration boundary for FonePay dynamic-QR payments.

    **Architecture / placeholder** — mirrors the TIGG connector approach:
    all FonePay interaction is funnelled through this single service so the
    rest of the module never talks to FonePay directly.  Today it renders a
    local QR that encodes the amount + reference; wiring the real provider is a
    matter of replacing :meth:`request_dynamic_qr` (and
    :meth:`check_payment_status`) with HTTP calls.

    Two production routes are anticipated, both drop-in here:

    * **FonePay Dynamic QR API** — POST the amount + merchant credentials to
      FonePay and render the ``qrString`` it returns (also enables automatic
      payment-status polling).
    * **NepalQR / EMVCo** — build a standards-compliant payload from the
      registered merchant PAN with a CRC-16 checksum, rendered locally.

    The placeholder payload below is intentionally *not* a valid FonePay /
    NepalQR string; it is a human-readable stand-in for demos and testing.
    """

    _name = 'parking.fonepay.connector'
    _description = 'FonePay Connector (dynamic QR / payment)'

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------
    @api.model
    def _get_settings(self):
        icp = self.env['ir.config_parameter'].sudo()
        enabled = icp.get_param('parking_management.fonepay_enabled')
        return {
            'enabled': enabled in TRUE_STRINGS or enabled is True,
            'merchant_code': icp.get_param('parking_management.fonepay_merchant_code') or '',
            'endpoint': icp.get_param('parking_management.fonepay_endpoint') or '',
        }

    # ------------------------------------------------------------------
    # QR payload / image
    # ------------------------------------------------------------------
    @api.model
    def build_payload(self, amount, reference):
        """Return the string to encode in the FonePay QR.

        Placeholder format (NOT a live FonePay/NepalQR payload)::

            FONEPAY|MERCHANT:<code>|AMOUNT:<amount>|REF:<reference>

        Replace with the FonePay ``qrString`` or an EMVCo/NepalQR payload
        (merchant PAN, amount tag ``54``, CRC-16 tag ``63``) in production.
        """
        settings = self._get_settings()
        merchant = settings['merchant_code'] or 'FONEPAY-MERCHANT'
        return 'FONEPAY|MERCHANT:%s|AMOUNT:%.2f|REF:%s' % (
            merchant, float(amount or 0.0), reference or '')

    @api.model
    def generate_qr_image(self, amount, reference):
        """Return a base64 PNG QR encoding ``amount``/``reference``.

        Returns ``False`` when there is nothing to charge.
        """
        if not amount or amount <= 0:
            return False
        payload = self.build_payload(amount, reference)
        png = self.env['ir.actions.report'].barcode(
            'QR', payload, width=300, height=300)
        return base64.b64encode(png)

    # ------------------------------------------------------------------
    # Provider entry points (stubs)
    # ------------------------------------------------------------------
    @api.model
    def request_dynamic_qr(self, amount, reference):
        """Obtain a dynamic QR for ``amount``.

        Placeholder: renders locally and reports ``generated_local``.  In
        production, issue the FonePay Dynamic-QR API request here and return
        its ``qrString`` / image plus the provider transaction id.
        """
        settings = self._get_settings()
        if settings['enabled'] and settings['endpoint']:
            # Real API call goes here; kept as a stub so no network I/O occurs.
            _logger.info(
                "FonePay enabled but live API not implemented; rendering "
                "local placeholder QR for reference %s", reference)
        return {
            'payload': self.build_payload(amount, reference),
            'image': self.generate_qr_image(amount, reference),
            'status': 'generated_local',
            'reference': reference,
        }

    @api.model
    def check_payment_status(self, reference):
        """Placeholder for FonePay payment-status polling.

        Always returns ``pending`` until the live API is wired in.
        """
        return 'pending'
