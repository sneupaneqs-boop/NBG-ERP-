# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
"""Model package for the Parking Management module.

Import order matters: models referenced through relational fields should be
importable, but Odoo resolves relations lazily by ``_name`` so the order here
is chosen purely for readability (configuration models first, then the
operational documents that depend on them).
"""
from . import parking_vehicle_type
from . import parking_category
from . import parking_rate
from . import parking_vehicle
from . import parking_slot
from . import parking_monthly_pass
from . import parking_ticket
from . import parking_payment
from . import fonepay_connector
from . import account_move
from . import parking_dashboard
from . import res_company
from . import res_config_settings
