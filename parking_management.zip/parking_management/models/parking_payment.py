# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

PAYMENT_METHODS = [
    ('cash', 'Cash'),
    ('card', 'Card'),
    ('esewa', 'eSewa'),
    ('khalti', 'Khalti'),
    ('fonepay', 'FonePay'),
    ('bank', 'Bank Transfer'),
]


class ParkingPayment(models.Model):
    """A payment collected against a parking ticket.

    A ticket may have several payments (e.g. split tender).  Posting a payment
    creates the accounting entry (implemented in Phase 4) and contributes to
    the ticket's ``amount_paid`` / ``is_paid`` computation.
    """

    _name = 'parking.payment'
    _description = 'Parking Payment'
    _inherit = ['mail.thread']
    _order = 'payment_date desc, id desc'

    name = fields.Char(
        string='Payment Reference',
        required=True,
        copy=False,
        readonly=True,
        index=True,
        default=lambda self: 'New',
    )
    ticket_id = fields.Many2one(
        comodel_name='parking.ticket',
        string='Ticket',
        required=True,
        ondelete='cascade',
        index=True,
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Customer',
        related='ticket_id.partner_id',
        store=True,
        readonly=True,
    )
    amount = fields.Monetary(
        string='Amount', currency_field='currency_id', required=True,
    )
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
    )
    payment_method = fields.Selection(
        selection=PAYMENT_METHODS,
        string='Payment Method',
        default='cash',
        required=True,
    )
    reference = fields.Char(
        string='Transaction Reference',
        help="External reference for wallet/card transactions "
             "(eSewa, Khalti, FonePay, card slip, etc.).",
    )
    payment_date = fields.Datetime(
        string='Payment Date',
        default=fields.Datetime.now,
        required=True,
    )
    operator_id = fields.Many2one(
        comodel_name='res.users',
        string='Collected By',
        default=lambda self: self.env.user,
    )
    move_id = fields.Many2one(
        comodel_name='account.move',
        string='Journal Entry',
        readonly=True,
        copy=False,
        help="Accounting entry generated for this payment (Phase 4).",
    )
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('posted', 'Posted'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='draft',
        required=True,
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda self: self.env.company,
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'parking.payment'
                ) or 'New'
        return super().create(vals_list)

    # --- Actions -----------------------------------------------------------
    def action_post(self):
        """Mark the payment posted and create its accounting entry."""
        self.write({'state': 'posted'})
        self._post_to_accounting()
        return True

    def action_cancel(self):
        for payment in self:
            if payment.move_id and payment.move_id.state == 'posted':
                payment.move_id.button_draft()
                payment.move_id.unlink()
        return self.write({'state': 'cancelled', 'move_id': False})

    def action_view_move(self):
        self.ensure_one()
        if not self.move_id:
            return False
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'res_id': self.move_id.id,
            'view_mode': 'form',
            'target': 'current',
        }

    # --- Accounting integration -------------------------------------------
    def _icp(self, key):
        return self.env['ir.config_parameter'].sudo().get_param(key)

    def _get_parking_journal(self):
        journal_id = self._icp('parking_management.journal_id')
        Journal = self.env['account.journal'].sudo()
        if journal_id:
            return Journal.browse(int(journal_id)).exists()
        # Fallback: first cash/bank journal of the company.
        return Journal.search(
            [('type', 'in', ('cash', 'bank')),
             ('company_id', '=', self.company_id.id)], limit=1)

    def _get_income_account(self):
        account_id = self._icp('parking_management.income_account_id')
        Account = self.env['account.account'].sudo()
        if account_id:
            return Account.browse(int(account_id)).exists()
        # account.account is multi-company (company_ids) in Odoo 18; match the
        # payment company when the field is present, else fall back broadly.
        domain = [('account_type', '=', 'income')]
        if 'company_ids' in Account._fields:
            domain.append(('company_ids', 'in', self.company_id.ids))
        return Account.search(domain, limit=1)

    def _get_tax_account(self):
        account_id = self._icp('parking_management.tax_account_id')
        Account = self.env['account.account'].sudo()
        if account_id:
            return Account.browse(int(account_id)).exists()
        return Account.browse()

    def _post_to_accounting(self):
        """Create and post a journal entry per payment.

        Debit  Cash/Bank (payment method account)      = amount
        Credit Parking Income                           = net (untaxed)
        Credit VAT Output (if configured)               = tax portion
        """
        Move = self.env['account.move'].sudo()
        for payment in self:
            if payment.move_id or payment.state != 'posted' or payment.amount <= 0:
                continue
            journal = payment._get_parking_journal()
            income = payment._get_income_account()
            debit_account = journal.default_account_id if journal else False
            if not (journal and income and debit_account):
                _logger.info(
                    "Parking payment %s posted without an accounting entry: "
                    "journal/income account not configured.", payment.name)
                continue
            tax_account = payment._get_tax_account()
            total = payment.amount
            tax = 0.0
            rate = payment.ticket_id.tax_rate or 0.0
            if tax_account and rate:
                tax = total - (total / (1.0 + rate / 100.0))
            net = total - tax
            label = "Parking %s - %s" % (
                payment.ticket_id.name or '', payment.name or '')
            line_ids = [
                (0, 0, {'account_id': debit_account.id, 'name': label,
                        'debit': total, 'credit': 0.0}),
                (0, 0, {'account_id': income.id, 'name': label,
                        'debit': 0.0, 'credit': net}),
            ]
            if tax > 0:
                line_ids.append((0, 0, {
                    'account_id': tax_account.id, 'name': 'VAT - %s' % label,
                    'debit': 0.0, 'credit': tax}))
            move = Move.create({
                'journal_id': journal.id,
                'move_type': 'entry',
                'date': fields.Date.context_today(payment),
                'ref': label,
                'parking_payment_id': payment.id,
                'line_ids': line_ids,
            })
            move.action_post()
            payment.move_id = move.id
        return True
