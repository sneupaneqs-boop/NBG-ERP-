# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models


class ParkingRate(models.Model):
    """Configurable rate plan for a vehicle type.

    All monetary values are configuration; nothing is hard-coded in the
    business logic.  The actual fee computation that consumes these fields is
    implemented in Phase 2 (the rate engine) via
    :meth:`~parking_management.models.parking_ticket.ParkingTicket._compute_charges`.
    """

    _name = 'parking.rate'
    _description = 'Parking Rate Plan'
    _order = 'sequence, id'

    name = fields.Char(string='Name', required=True, default='New Rate Plan')
    sequence = fields.Integer(string='Sequence', default=10)
    active = fields.Boolean(string='Active', default=True)
    vehicle_type_id = fields.Many2one(
        comodel_name='parking.vehicle.type',
        string='Vehicle Type',
        required=True,
        ondelete='cascade',
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda self: self.env.company,
    )
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        string='Currency',
        related='company_id.currency_id',
        store=True,
        readonly=True,
    )

    # --- Charges -----------------------------------------------------------
    hourly_charge = fields.Monetary(
        string='Hourly Charge',
        currency_field='currency_id',
        help="Flat charge per started hour. This is the primary value used by "
             "the rate engine (e.g. Bike Rs.30/hr, Car Rs.50/hr).",
    )
    first_hour_charge = fields.Monetary(
        string='First Hour Charge',
        currency_field='currency_id',
        help="Optional: distinct charge for the first hour. Kept for advanced "
             "tariffs; the default engine uses the flat Hourly Charge.",
    )
    additional_hour_charge = fields.Monetary(
        string='Additional Hour Charge',
        currency_field='currency_id',
        help="Charge applied per additional started hour after the first.",
    )
    max_daily_charge = fields.Monetary(
        string='Maximum Daily Charge',
        currency_field='currency_id',
        help="Cap applied per 24h period. 0 means no cap.",
    )
    night_charge = fields.Monetary(
        string='Night Charge',
        currency_field='currency_id',
        help="Flat charge applied when parking overlaps the night window.",
    )
    lost_ticket_charge = fields.Monetary(
        string='Lost Ticket Charge',
        currency_field='currency_id',
        help="Penalty charged when a customer loses their ticket.",
    )
    monthly_charge = fields.Monetary(
        string='Monthly Pass Charge',
        currency_field='currency_id',
        help="Default amount billed for a monthly pass of this vehicle type.",
    )

    # --- Timing rules ------------------------------------------------------
    grace_period = fields.Integer(
        string='Grace Period (minutes)',
        default=0,
        help="Free minutes after entry during which no charge applies.",
    )
    night_start = fields.Float(
        string='Night Window Start',
        default=22.0,
        help="Start of the night window (24h float, e.g. 22.5 = 22:30).",
    )
    night_end = fields.Float(
        string='Night Window End',
        default=6.0,
        help="End of the night window (24h float).",
    )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('name') or vals['name'] == 'New Rate Plan':
                vtype = self.env['parking.vehicle.type'].browse(
                    vals.get('vehicle_type_id')
                )
                if vtype:
                    vals['name'] = _rate_default_name(vtype.name)
        return super().create(vals_list)

    @api.depends('name', 'vehicle_type_id')
    def _compute_display_name(self):
        for rate in self:
            label = rate.name or ''
            type_name = rate.vehicle_type_id.name
            if type_name and type_name not in label:
                label = f"{type_name} - {label}"
            rate.display_name = label


def _rate_default_name(type_name):
    """Return a friendly default rate-plan name for ``type_name``."""
    return f"{type_name} Rate Plan"
