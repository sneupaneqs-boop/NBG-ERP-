# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import fields, models


class AccountMove(models.Model):
    """Link journal entries back to the parking payment that created them."""

    _inherit = 'account.move'

    parking_payment_id = fields.Many2one(
        comodel_name='parking.payment',
        string='Parking Payment',
        readonly=True,
        index=True,
        copy=False,
    )
