# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models


class ParkingMonthlyPass(models.Model):
    """A prepaid monthly parking subscription for a vehicle.

    While a pass is ``active`` and within its validity window, entries for the
    associated vehicle are not charged the per-hour rate (enforced by the rate
    engine in Phase 2).
    """

    _name = 'parking.monthly.pass'
    _description = 'Parking Monthly Pass'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'valid_from desc, id desc'

    name = fields.Char(
        string='Pass Number',
        required=True,
        copy=False,
        readonly=True,
        index=True,
        default=lambda self: 'New',
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Customer',
        required=True,
        tracking=True,
    )
    vehicle_id = fields.Many2one(
        comodel_name='parking.vehicle',
        string='Vehicle',
        required=True,
        tracking=True,
    )
    vehicle_type_id = fields.Many2one(
        comodel_name='parking.vehicle.type',
        string='Vehicle Type',
        related='vehicle_id.vehicle_type_id',
        store=True,
        readonly=True,
    )
    valid_from = fields.Date(
        string='Valid From',
        required=True,
        default=fields.Date.context_today,
        tracking=True,
    )
    valid_to = fields.Date(string='Valid To', required=True, tracking=True)

    amount = fields.Monetary(
        string='Amount', currency_field='currency_id', tracking=True,
    )
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
    )
    payment_status = fields.Selection(
        selection=[('unpaid', 'Unpaid'), ('paid', 'Paid')],
        string='Payment Status',
        default='unpaid',
        tracking=True,
    )
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Active'),
            ('expired', 'Expired'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='draft',
        required=True,
        tracking=True,
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda self: self.env.company,
    )
    notes = fields.Text(string='Notes')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'parking.monthly.pass'
                ) or 'New'
        return super().create(vals_list)

    # --- State transitions (logic hooks refined in later phases) -----------
    def action_activate(self):
        return self.write({'state': 'active'})

    def action_expire(self):
        return self.write({'state': 'expired'})

    def action_cancel(self):
        return self.write({'state': 'cancelled'})

    def action_draft(self):
        return self.write({'state': 'draft'})
