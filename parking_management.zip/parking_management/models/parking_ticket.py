# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
import base64
import math

from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import format_duration

from .parking_payment import PAYMENT_METHODS

TRUE_STRINGS = ('True', 'true', '1', 'yes', 'on')


class ParkingTicket(models.Model):
    """A parking session, from vehicle entry to paid exit.

    Phase 2 adds the rate engine and the full entry -> park -> exit -> pay
    workflow:

    * **Free time** comes from the ticket's :class:`parking.category`
      (e.g. 45/90/0 min) and is *deducted* from the parked duration.
    * The remaining time is billed by **rounding up to the next started
      hour** at the vehicle type's flat hourly rate.
    * VAT is treated as **tax-inclusive**: the grand total is what the
      customer pays and the VAT component is back-calculated for the receipt.
    * Monthly-pass holders park for free; lost tickets are billed the
      configured lost-ticket charge.
    """

    _name = 'parking.ticket'
    _description = 'Parking Ticket'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'entry_time desc, id desc'

    # --- Identification ----------------------------------------------------
    name = fields.Char(
        string='Ticket Number', required=True, copy=False, readonly=True,
        index=True, default=lambda self: 'New',
    )
    coupon_number = fields.Char(
        string='Coupon Number', copy=False, index=True, tracking=True,
        help="Number printed on the coupon dispensed by the entry machine.",
    )
    state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Parked'),
            ('to_pay', 'To Pay'),
            ('paid', 'Paid'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status', default='draft', required=True, tracking=True, index=True,
    )

    # --- Vehicle -----------------------------------------------------------
    vehicle_id = fields.Many2one('parking.vehicle', string='Vehicle', index=True)
    vehicle_number = fields.Char(
        string='Vehicle Number', required=True, index=True, tracking=True,
    )
    vehicle_type_id = fields.Many2one(
        'parking.vehicle.type', string='Vehicle Type', required=True, tracking=True,
    )
    category_id = fields.Many2one(
        'parking.category', string='Parking Category', required=True,
        default=lambda self: self._default_category(), tracking=True,
        help="Determines the free-parking allowance for this session.",
    )
    owner_name = fields.Char(string='Owner Name')
    partner_id = fields.Many2one('res.partner', string='Customer')
    phone = fields.Char(string='Phone')

    # --- Timing ------------------------------------------------------------
    entry_time = fields.Datetime(
        string='Entry Time', default=fields.Datetime.now, required=True, tracking=True,
    )
    exit_time = fields.Datetime(string='Exit Time', tracking=True, copy=False)
    duration = fields.Float(
        string='Duration (hours)', compute='_compute_duration', store=True,
        help="Elapsed parking time in hours.",
    )
    duration_display = fields.Char(string='Duration', compute='_compute_duration_display')
    free_minutes = fields.Integer(
        string='Free Minutes', related='category_id.free_minutes', readonly=True,
    )
    billed_hours = fields.Integer(
        string='Billed Hours', compute='_compute_charges', store=True,
        help="Chargeable time rounded up to whole hours.",
    )

    # --- Location ----------------------------------------------------------
    slot_id = fields.Many2one('parking.slot', string='Parking Slot', copy=False)
    gate_number = fields.Char(string='Gate Number')

    # --- Rate & amounts ----------------------------------------------------
    rate_id = fields.Many2one(
        'parking.rate', string='Rate Plan', compute='_compute_rate_id',
        store=True, readonly=False,
    )
    currency_id = fields.Many2one(
        'res.currency', string='Currency',
        default=lambda self: self.env.company.currency_id,
    )
    hourly_rate = fields.Monetary(
        string='Hourly Rate', currency_field='currency_id',
        compute='_compute_charges', store=True,
    )
    tax_rate = fields.Float(
        string='Tax Rate (%)', default=lambda self: self._default_tax_rate(),
        help="VAT percentage. Treated as tax-inclusive in the grand total.",
    )
    amount_total = fields.Monetary(
        string='Parking Charge', currency_field='currency_id',
        compute='_compute_charges', store=True,
        help="Gross parking charge (VAT inclusive) from the rate engine.",
    )
    discount = fields.Monetary(string='Discount', currency_field='currency_id')
    amount_untaxed = fields.Monetary(
        string='Untaxed Amount', currency_field='currency_id',
        compute='_compute_tax', store=True,
    )
    tax_amount = fields.Monetary(
        string='VAT', currency_field='currency_id',
        compute='_compute_tax', store=True,
    )
    grand_total = fields.Monetary(
        string='Grand Total', currency_field='currency_id',
        compute='_compute_grand_total', store=True,
    )

    # --- Payment -----------------------------------------------------------
    payment_ids = fields.One2many('parking.payment', 'ticket_id', string='Payments')
    amount_paid = fields.Monetary(
        string='Amount Paid', currency_field='currency_id',
        compute='_compute_amount_paid', store=True,
    )
    amount_residual = fields.Monetary(
        string='Amount Due', currency_field='currency_id',
        compute='_compute_amount_paid', store=True,
    )
    is_paid = fields.Boolean(string='Paid', compute='_compute_amount_paid', store=True)
    payment_method = fields.Selection(selection=PAYMENT_METHODS, string='Payment Method')

    # --- Codes -------------------------------------------------------------
    barcode = fields.Char(
        string='Barcode', copy=False, index=True,
        compute='_compute_codes', store=True,
    )
    qr_code = fields.Binary(
        string='QR Code', attachment=False, copy=False,
        compute='_compute_codes', store=True,
        help="QR encoding the coupon/ticket reference (scan to open ticket).",
    )
    barcode_image = fields.Binary(
        string='Barcode Image', attachment=False, copy=False,
        compute='_compute_codes', store=True,
    )
    fonepay_qr_image = fields.Binary(
        string='FonePay QR', attachment=False, copy=False,
        compute='_compute_fonepay_qr_image',
        help="Dynamic FonePay QR encoding the amount due (placeholder until "
             "the live FonePay integration is enabled).",
    )

    # --- Misc --------------------------------------------------------------
    operator_id = fields.Many2one(
        'res.users', string='Operator', default=lambda self: self.env.user, tracking=True,
    )
    monthly_pass_id = fields.Many2one('parking.monthly.pass', string='Monthly Pass', copy=False)
    is_pass_covered = fields.Boolean(
        string='Covered by Pass', compute='_compute_charges', store=True,
    )
    is_lost_ticket = fields.Boolean(string='Lost Ticket', copy=False, tracking=True)
    remarks = fields.Text(string='Remarks')
    company_id = fields.Many2one(
        'res.company', string='Company', default=lambda self: self.env.company,
    )

    _sql_constraints = [
        ('exit_after_entry',
         "CHECK(exit_time IS NULL OR entry_time IS NULL OR exit_time >= entry_time)",
         'Exit time cannot be earlier than entry time.'),
    ]

    # ----------------------------------------------------------------------
    # Defaults
    # ----------------------------------------------------------------------
    @api.model
    def _default_category(self):
        return self.env.ref('parking_management.category_other', raise_if_not_found=False)

    @api.model
    def _default_tax_rate(self):
        param = self.env['ir.config_parameter'].sudo().get_param(
            'parking_management.default_tax_rate', 0.0)
        try:
            return float(param or 0.0)
        except (TypeError, ValueError):
            return 0.0

    # ----------------------------------------------------------------------
    # Compute methods
    # ----------------------------------------------------------------------
    @api.depends('entry_time', 'exit_time')
    def _compute_duration(self):
        now = fields.Datetime.now()
        for ticket in self:
            end = ticket.exit_time or now
            if ticket.entry_time and end >= ticket.entry_time:
                ticket.duration = (end - ticket.entry_time).total_seconds() / 3600.0
            else:
                ticket.duration = 0.0

    @api.depends('duration')
    def _compute_duration_display(self):
        for ticket in self:
            ticket.duration_display = format_duration(ticket.duration)

    @api.depends('name', 'coupon_number')
    def _compute_codes(self):
        Report = self.env['ir.actions.report']
        for ticket in self:
            value = ticket.coupon_number or (
                ticket.name if ticket.name and ticket.name != 'New' else '')
            if value:
                ticket.barcode = value
                ticket.qr_code = base64.b64encode(
                    Report.barcode('QR', value, width=300, height=300))
                ticket.barcode_image = base64.b64encode(
                    Report.barcode('Code128', value, width=600, height=150))
            else:
                ticket.barcode = False
                ticket.qr_code = False
                ticket.barcode_image = False

    @api.depends('grand_total', 'amount_residual')
    def _compute_fonepay_qr_image(self):
        connector = self.env['parking.fonepay.connector']
        for ticket in self:
            amount = ticket.amount_residual if ticket.amount_residual > 0 else ticket.grand_total
            ticket.fonepay_qr_image = connector.generate_qr_image(amount, ticket.name)

    @api.depends('vehicle_type_id')
    def _compute_rate_id(self):
        for ticket in self:
            if ticket.rate_id and ticket.rate_id.vehicle_type_id == ticket.vehicle_type_id:
                continue
            ticket.rate_id = ticket._find_rate()

    @api.depends(
        'entry_time', 'exit_time', 'category_id.free_minutes', 'is_lost_ticket',
        'rate_id', 'rate_id.hourly_charge', 'rate_id.lost_ticket_charge',
        'rate_id.max_daily_charge', 'monthly_pass_id', 'monthly_pass_id.state',
        'vehicle_id.active_pass_id',
    )
    def _compute_charges(self):
        for ticket in self:
            rate = ticket.rate_id
            ticket.hourly_rate = rate.hourly_charge if rate else 0.0
            covered = ticket._pass_is_active()
            ticket.is_pass_covered = covered
            billed_hours = 0
            fee = 0.0
            if covered:
                fee = 0.0
            elif ticket.is_lost_ticket:
                fee = rate.lost_ticket_charge if rate else 0.0
            elif ticket.entry_time and ticket.exit_time and rate:
                total_minutes = max(
                    0.0, (ticket.exit_time - ticket.entry_time).total_seconds() / 60.0)
                free_minutes = ticket.category_id.free_minutes or 0
                chargeable = max(0.0, total_minutes - free_minutes)
                billed_hours = int(math.ceil(chargeable / 60.0)) if chargeable > 0 else 0
                fee = billed_hours * rate.hourly_charge
                # Optional daily cap (only when configured > 0).
                if rate.max_daily_charge and rate.max_daily_charge > 0:
                    days = max(1, int(math.ceil(total_minutes / (24 * 60))))
                    fee = min(fee, rate.max_daily_charge * days)
            ticket.billed_hours = billed_hours
            ticket.amount_total = fee

    @api.depends('amount_total', 'discount')
    def _compute_grand_total(self):
        for ticket in self:
            ticket.grand_total = max(0.0, ticket.amount_total - ticket.discount)

    @api.depends('grand_total', 'tax_rate')
    def _compute_tax(self):
        for ticket in self:
            rate = ticket.tax_rate or 0.0
            if rate:
                untaxed = ticket.grand_total / (1.0 + rate / 100.0)
                ticket.amount_untaxed = untaxed
                ticket.tax_amount = ticket.grand_total - untaxed
            else:
                ticket.amount_untaxed = ticket.grand_total
                ticket.tax_amount = 0.0

    @api.depends('payment_ids.amount', 'payment_ids.state', 'grand_total')
    def _compute_amount_paid(self):
        for ticket in self:
            paid = sum(p.amount for p in ticket.payment_ids if p.state == 'posted')
            ticket.amount_paid = paid
            ticket.amount_residual = ticket.grand_total - paid
            ticket.is_paid = ticket.grand_total > 0 and paid >= ticket.grand_total

    # ----------------------------------------------------------------------
    # Helpers
    # ----------------------------------------------------------------------
    def _pass_is_active(self):
        self.ensure_one()
        if self.monthly_pass_id and self.monthly_pass_id.state == 'active':
            return True
        return bool(self.vehicle_id and self.vehicle_id.active_pass_id)

    def _find_rate(self):
        self.ensure_one()
        if not self.vehicle_type_id:
            return self.env['parking.rate']
        return self.env['parking.rate'].search(
            [('vehicle_type_id', '=', self.vehicle_type_id.id), ('active', '=', True)],
            limit=1)

    def _auto_assign_enabled(self):
        param = self.env['ir.config_parameter'].sudo().get_param(
            'parking_management.auto_assign_slot')
        return param in TRUE_STRINGS or param is True

    def _find_free_slot(self):
        self.ensure_one()
        Slot = self.env['parking.slot']
        domain = [('state', '=', 'available'), ('active', '=', True)]
        slot = Slot.search(
            domain + ['|', ('vehicle_type_id', '=', self.vehicle_type_id.id),
                      ('vehicle_type_id', '=', False)],
            limit=1)
        return slot

    def _occupy_slot(self):
        for ticket in self:
            if ticket.slot_id:
                ticket.slot_id.write({
                    'state': 'occupied', 'current_ticket_id': ticket.id})

    def _release_slot(self):
        for ticket in self:
            if ticket.slot_id and ticket.slot_id.current_ticket_id == ticket:
                ticket.slot_id.write({'state': 'available', 'current_ticket_id': False})

    def _register_payment(self, amount, method, reference=False):
        """Record a posted payment and close the session when fully paid."""
        self.ensure_one()
        if amount <= 0:
            raise UserError("Payment amount must be greater than zero.")
        payment = self.env['parking.payment'].create({
            'ticket_id': self.id,
            'amount': amount,
            'payment_method': method,
            'reference': reference or False,
            'operator_id': self.env.user.id,
        })
        payment.action_post()
        self.payment_method = method
        if self.amount_residual <= 0:
            self.action_mark_paid()
        return True

    # ----------------------------------------------------------------------
    # ORM overrides
    # ----------------------------------------------------------------------
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'parking.ticket') or 'New'
        return super().create(vals_list)

    # ----------------------------------------------------------------------
    # Onchange helpers
    # ----------------------------------------------------------------------
    @api.onchange('vehicle_id')
    def _onchange_vehicle_id(self):
        if self.vehicle_id:
            self.vehicle_number = self.vehicle_id.name
            if self.vehicle_id.vehicle_type_id:
                self.vehicle_type_id = self.vehicle_id.vehicle_type_id
            self.owner_name = self.vehicle_id.owner_name
            self.partner_id = self.vehicle_id.partner_id
            self.phone = self.vehicle_id.phone
            if self.vehicle_id.active_pass_id:
                self.monthly_pass_id = self.vehicle_id.active_pass_id

    # ----------------------------------------------------------------------
    # Workflow actions
    # ----------------------------------------------------------------------
    def action_confirm_entry(self):
        """Register the vehicle as parked: assign rate, slot, barcode."""
        for ticket in self:
            if ticket.state not in ('draft',):
                continue
            if not ticket.entry_time:
                ticket.entry_time = fields.Datetime.now()
            if not ticket.rate_id:
                ticket.rate_id = ticket._find_rate()
            if not ticket.slot_id and ticket._auto_assign_enabled():
                slot = ticket._find_free_slot()
                if slot:
                    ticket.slot_id = slot
            ticket.state = 'active'
            ticket._occupy_slot()
        return True

    def action_register_exit(self):
        """Close the parking session and open the payment screen.

        Works both from ``active`` (entry registered in Odoo) and directly from
        ``draft`` (exit-only mode: the coupon/entry time was captured by the
        external machine and typed in here).
        """
        for ticket in self:
            if ticket.state not in ('draft', 'active'):
                continue
            if not ticket.exit_time:
                ticket.exit_time = fields.Datetime.now()
            ticket.state = 'to_pay'
        if len(self) == 1 and not self.is_pass_covered and self.amount_residual > 0:
            return self.action_register_payment()
        # Pass-covered or zero-charge sessions close immediately.
        for ticket in self:
            if ticket.state == 'to_pay' and ticket.grand_total <= 0:
                ticket.action_mark_paid()
        return True

    def action_register_payment(self):
        """Open the payment wizard for this ticket."""
        self.ensure_one()
        return {
            'name': 'Register Payment',
            'type': 'ir.actions.act_window',
            'res_model': 'parking.payment.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_ticket_id': self.id},
        }

    def action_mark_paid(self):
        for ticket in self:
            ticket.state = 'paid'
            ticket._release_slot()
        return True

    def action_lost_ticket(self):
        """Flag the ticket as lost and bill the lost-ticket charge."""
        self.ensure_one()
        if not self.rate_id:
            raise ValidationError(
                "No rate plan found for this vehicle type; cannot apply the "
                "lost-ticket charge.")
        self.is_lost_ticket = True
        if not self.exit_time:
            self.exit_time = fields.Datetime.now()
        self.state = 'to_pay'
        return self.action_register_payment()

    def action_cancel(self):
        for ticket in self:
            ticket._release_slot()
            ticket.state = 'cancelled'
        return True

    def action_draft(self):
        return self.write({'state': 'draft'})
