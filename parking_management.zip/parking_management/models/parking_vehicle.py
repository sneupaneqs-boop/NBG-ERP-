# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models


class ParkingVehicle(models.Model):
    """A vehicle known to the system.

    Vehicles are optional for a ticket (a walk-in can be ticketed by plate
    number alone) but registering them enables monthly passes, owner history
    and faster entry.
    """

    _name = 'parking.vehicle'
    _description = 'Parking Vehicle'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name'
    _rec_name = 'name'

    name = fields.Char(
        string='Vehicle Number',
        required=True,
        index=True,
        tracking=True,
        help="Registration / number plate of the vehicle.",
    )
    vehicle_type_id = fields.Many2one(
        comodel_name='parking.vehicle.type',
        string='Vehicle Type',
        tracking=True,
    )
    owner_name = fields.Char(string='Owner Name', tracking=True)
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Owner / Customer',
        help="Linked contact used for invoicing and monthly passes.",
    )
    phone = fields.Char(string='Phone')
    company_name = fields.Char(string='Company / Organisation')
    color = fields.Char(string='Colour')
    model = fields.Char(string='Model')
    active = fields.Boolean(string='Active', default=True)
    notes = fields.Text(string='Notes')

    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda self: self.env.company,
    )

    ticket_ids = fields.One2many(
        comodel_name='parking.ticket',
        inverse_name='vehicle_id',
        string='Tickets',
    )
    ticket_count = fields.Integer(
        string='Ticket Count', compute='_compute_ticket_count',
    )
    monthly_pass_ids = fields.One2many(
        comodel_name='parking.monthly.pass',
        inverse_name='vehicle_id',
        string='Monthly Passes',
    )
    active_pass_id = fields.Many2one(
        comodel_name='parking.monthly.pass',
        string='Active Pass',
        compute='_compute_active_pass',
        help="Currently valid monthly pass for this vehicle, if any.",
    )
    has_active_pass = fields.Boolean(
        string='Has Active Pass', compute='_compute_active_pass',
    )

    _sql_constraints = [
        ('number_uniq', 'unique(name, company_id)',
         'A vehicle with this number already exists for this company.'),
    ]

    @api.depends('ticket_ids')
    def _compute_ticket_count(self):
        for vehicle in self:
            vehicle.ticket_count = len(vehicle.ticket_ids)

    @api.depends('monthly_pass_ids.state', 'monthly_pass_ids.valid_from',
                 'monthly_pass_ids.valid_to')
    def _compute_active_pass(self):
        today = fields.Date.context_today(self)
        for vehicle in self:
            active_pass = vehicle.monthly_pass_ids.filtered(
                lambda p: p.state == 'active'
                and p.valid_from and p.valid_from <= today
                and p.valid_to and p.valid_to >= today
            )[:1]
            vehicle.active_pass_id = active_pass
            vehicle.has_active_pass = bool(active_pass)

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            self.owner_name = self.owner_name or self.partner_id.name
            self.phone = self.phone or self.partner_id.phone
