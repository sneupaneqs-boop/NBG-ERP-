# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import fields, models


class ResCompany(models.Model):
    """Company-level parking settings that need real storage (images, etc.)."""

    _inherit = 'res.company'

    parking_fonepay_qr = fields.Binary(
        string='FonePay QR',
        help="Static merchant FonePay QR image shown to customers on the "
             "payment screen for online payment.",
    )
