# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models


class ParkingVehicleType(models.Model):
    """A category of vehicle (Bike, Car, Bus, ...).

    Vehicle types are the pivot around which the rate engine is configured:
    every :class:`~odoo.addons.parking_management.models.parking_rate.ParkingRate`
    targets exactly one vehicle type, and tickets copy the type from the
    vehicle to look up the applicable rate.
    """

    _name = 'parking.vehicle.type'
    _description = 'Parking Vehicle Type'
    _order = 'sequence, name'

    name = fields.Char(string='Name', required=True, translate=True)
    code = fields.Char(
        string='Code',
        help="Short unique code used on tickets and in reports (e.g. BIKE, CAR).",
    )
    sequence = fields.Integer(string='Sequence', default=10)
    description = fields.Text(string='Description')
    color = fields.Integer(string='Colour Index')
    active = fields.Boolean(string='Active', default=True)

    rate_ids = fields.One2many(
        comodel_name='parking.rate',
        inverse_name='vehicle_type_id',
        string='Rate Plans',
    )
    rate_count = fields.Integer(
        string='Rate Plan Count', compute='_compute_rate_count',
    )
    vehicle_count = fields.Integer(
        string='Vehicles', compute='_compute_vehicle_count',
    )

    _sql_constraints = [
        ('code_uniq', 'unique(code)', 'The vehicle type code must be unique.'),
    ]

    @api.depends('rate_ids')
    def _compute_rate_count(self):
        for vtype in self:
            vtype.rate_count = len(vtype.rate_ids)

    def _compute_vehicle_count(self):
        Vehicle = self.env['parking.vehicle']
        data = Vehicle._read_group(
            [('vehicle_type_id', 'in', self.ids)],
            groupby=['vehicle_type_id'],
            aggregates=['__count'],
        )
        mapped = {vtype.id: count for vtype, count in data}
        for vtype in self:
            vtype.vehicle_count = mapped.get(vtype.id, 0)
