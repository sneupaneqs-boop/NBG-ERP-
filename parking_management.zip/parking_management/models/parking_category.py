# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import api, fields, models


class ParkingCategory(models.Model):
    """A parking service category / validation heading.

    Each category grants a configurable amount of free parking time before the
    per-hour rate applies.  Seeded examples:

    * **Club parking** – 45 minutes free
    * **Special Club Parking** – 90 minutes free
    * **Other** – 0 minutes free (default, plain parking)

    The category supplies only the *free minutes*; the hourly charge always
    comes from the vehicle type's :class:`parking.rate`, so a Bike and a Car in
    the same category are billed at their own rates.
    """

    _name = 'parking.category'
    _description = 'Parking Category'
    _order = 'sequence, id'

    name = fields.Char(string='Name', required=True, translate=True)
    sequence = fields.Integer(string='Sequence', default=10)
    free_minutes = fields.Integer(
        string='Free Minutes',
        default=0,
        help="Minutes of free parking granted by this category before the "
             "hourly rate starts to apply.",
    )
    color = fields.Integer(string='Colour Index')
    active = fields.Boolean(string='Active', default=True)
    note = fields.Text(string='Description')

    _sql_constraints = [
        ('free_minutes_positive', 'CHECK(free_minutes >= 0)',
         'Free minutes cannot be negative.'),
    ]

    @api.depends('name', 'free_minutes')
    def _compute_display_name(self):
        for category in self:
            if category.free_minutes:
                category.display_name = f"{category.name} ({category.free_minutes} min free)"
            else:
                category.display_name = category.name or ''
