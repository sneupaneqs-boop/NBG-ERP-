# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    """Global, non-hard-coded configuration for the Parking Management module.

    Values are persisted through ``ir.config_parameter`` so they survive across
    sessions and are read by the rate engine, receipts and accounting layers in
    later phases.
    """

    _inherit = 'res.config.settings'

    parking_default_tax_rate = fields.Float(
        string='Default Tax Rate (%)',
        config_parameter='parking_management.default_tax_rate',
        help="Tax percentage applied to parking charges by default.",
    )
    parking_auto_assign_slot = fields.Boolean(
        string='Auto-assign Slot on Entry',
        config_parameter='parking_management.auto_assign_slot',
        help="Automatically pick the first free compatible slot at entry.",
    )
    parking_default_grace_period = fields.Integer(
        string='Default Grace Period (minutes)',
        config_parameter='parking_management.default_grace_period',
    )
    parking_receipt_width = fields.Selection(
        selection=[('58', '58 mm'), ('80', '80 mm')],
        string='Thermal Receipt Width',
        default='80',
        config_parameter='parking_management.receipt_width',
    )
    parking_income_account_id = fields.Many2one(
        comodel_name='account.account',
        string='Parking Income Account',
        config_parameter='parking_management.income_account_id',
        help="Account credited when a parking payment is posted.",
    )
    parking_journal_id = fields.Many2one(
        comodel_name='account.journal',
        string='Parking Journal',
        config_parameter='parking_management.journal_id',
        help="Journal used for parking payment entries.",
    )
    parking_tax_account_id = fields.Many2one(
        comodel_name='account.account',
        string='VAT Output Account',
        config_parameter='parking_management.tax_account_id',
        help="Optional. If set, the VAT portion of each payment is credited "
             "here and only the net amount to Parking Income.",
    )
    parking_fonepay_qr = fields.Binary(
        string='Static FonePay QR (fallback)',
        related='company_id.parking_fonepay_qr',
        readonly=False,
        help="Optional static merchant FonePay QR. The payment screen normally "
             "generates a dynamic QR for the exact amount instead.",
    )
    parking_fonepay_enabled = fields.Boolean(
        string='Enable FonePay Dynamic QR',
        config_parameter='parking_management.fonepay_enabled',
        help="Generate a FonePay QR for the exact amount at exit. Until the "
             "live API is wired in, a local placeholder QR is produced.",
    )
    parking_fonepay_merchant_code = fields.Char(
        string='FonePay Merchant Code',
        config_parameter='parking_management.fonepay_merchant_code',
    )
    parking_fonepay_endpoint = fields.Char(
        string='FonePay API Endpoint',
        config_parameter='parking_management.fonepay_endpoint',
    )
    parking_tigg_enabled = fields.Boolean(
        string='Enable TIGG Sync',
        config_parameter='parking_management.tigg_enabled',
        help="Toggle the (future) TIGG accounting API integration.",
    )
    parking_tigg_endpoint = fields.Char(
        string='TIGG API Endpoint',
        config_parameter='parking_management.tigg_endpoint',
    )
