# -*- coding: utf-8 -*-
# Part of the parking_management Odoo module.
{
    'name': 'Parking Management',
    'version': '18.0.1.0.0',
    'category': 'Operations/Parking',
    'summary': 'Complete parking management: entry/exit, ticketing, '
               'QR & barcode, rate engine, payments, passes and reporting.',
    'description': """
Parking Management
==================

A production-ready parking management ERP for Odoo 18 Community.

Highlights
----------
* Vehicle entry with automatic ticket, QR code and barcode generation.
* Configurable rate engine (first hour, additional hour, night, daily cap,
  grace period, lost ticket fee, monthly charge) with **no hard-coded** values.
* Parking slot management with a visual, colour-coded dashboard.
* Vehicle exit with automatic duration, fee, tax and discount calculation.
* Multi-method payment recording (Cash, Card, eSewa, Khalti, FonePay, Bank)
  with Odoo Accounting integration.
* Monthly parking passes and lost-ticket handling.
* Role based security (Administrator, Manager, Cashier, Gate Operator,
  Security Guard).
* Architecture ready for future TIGG accounting API and barrier-gate
  integration.

This is **Phase 1** of the implementation: data model, security, menus
and views.  Business logic, QR/barcode, printing, accounting, dashboard,
reporting, tests and documentation follow in subsequent phases.
""",
    'author': 'NBG',
    'website': 'https://www.example.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'account',
        'web',
    ],
    'data': [
        # Security
        'security/parking_security.xml',
        'security/ir.model.access.csv',
        # Data
        'data/parking_sequence.xml',
        'data/parking_category_data.xml',
        'data/parking_data.xml',
        # Reports (actions referenced by ticket-form print buttons -> load first)
        'report/parking_reports.xml',
        'report/parking_collection_report.xml',
        # Views. Actions must be loaded before any view (stat button) or menu
        # that references them, hence tickets precede vehicles.
        'views/parking_vehicle_type_views.xml',
        'views/parking_category_views.xml',
        'views/parking_rate_views.xml',
        'views/parking_slot_views.xml',
        'wizard/parking_payment_wizard_views.xml',
        'wizard/parking_report_wizard_views.xml',
        'views/parking_ticket_views.xml',
        'views/parking_vehicle_views.xml',
        'views/parking_monthly_pass_views.xml',
        'views/parking_payment_views.xml',
        'views/parking_dashboard_views.xml',
        'views/res_config_settings_views.xml',
        'views/parking_menus.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'parking_management/static/src/dashboard/parking_dashboard.scss',
            'parking_management/static/src/dashboard/parking_dashboard.js',
            'parking_management/static/src/dashboard/parking_dashboard.xml',
        ],
    },
    'demo': [
        'data/parking_demo.xml',
    ],
    'application': True,
    'installable': True,
    'auto_install': False,
}
