/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { loadJS } from "@web/core/assets";
import { Component, onWillStart, onMounted, onWillUnmount, useRef, useState } from "@odoo/owl";

/**
 * Parking dashboard: KPI tiles plus a daily-revenue bar chart and a
 * vehicle-type / payment-method pie chart, rendered with Chart.js.
 */
export class ParkingDashboard extends Component {
    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({ loading: true, data: null });
        this.barRef = useRef("barChart");
        this.pieRef = useRef("methodChart");
        this.typeRef = useRef("typeChart");
        this.charts = [];

        onWillStart(async () => {
            await loadJS("/web/static/lib/Chart/Chart.js");
            await this.loadData();
        });
        onMounted(() => this.renderCharts());
        onWillUnmount(() => this.destroyCharts());
    }

    async loadData() {
        this.state.data = await this.orm.call("parking.dashboard", "get_dashboard_data", []);
        this.state.loading = false;
    }

    async onRefresh() {
        await this.loadData();
        this.renderCharts();
    }

    get kpi() {
        return this.state.data ? this.state.data.kpi : {};
    }

    formatMoney(value) {
        const sym = this.state.data ? this.state.data.currency_symbol : "";
        return `${sym} ${(value || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    formatDuration(hours) {
        const h = Math.floor(hours || 0);
        const m = Math.round(((hours || 0) - h) * 60);
        return `${h}h ${m}m`;
    }

    destroyCharts() {
        this.charts.forEach((c) => c && c.destroy());
        this.charts = [];
    }

    renderCharts() {
        if (!this.state.data || typeof Chart === "undefined") {
            return;
        }
        this.destroyCharts();
        const d = this.state.data;
        const palette = ["#2152A0", "#1F9D55", "#E67E22", "#8E44AD", "#16A085", "#C0392B", "#7F8C8D"];

        if (this.barRef.el) {
            this.charts.push(new Chart(this.barRef.el, {
                type: "bar",
                data: {
                    labels: d.daily.labels,
                    datasets: [{ label: "Revenue", data: d.daily.values, backgroundColor: "#2152A0", borderRadius: 4 }],
                },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } },
            }));
        }
        if (this.typeRef.el && d.by_type.labels.length) {
            this.charts.push(new Chart(this.typeRef.el, {
                type: "doughnut",
                data: { labels: d.by_type.labels, datasets: [{ data: d.by_type.values, backgroundColor: palette }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } },
            }));
        }
        if (this.pieRef.el && d.by_method.labels.length) {
            this.charts.push(new Chart(this.pieRef.el, {
                type: "pie",
                data: { labels: d.by_method.labels, datasets: [{ data: d.by_method.values, backgroundColor: palette }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } },
            }));
        }
    }
}

ParkingDashboard.template = "parking_management.ParkingDashboard";
registry.category("actions").add("parking_dashboard", ParkingDashboard);
